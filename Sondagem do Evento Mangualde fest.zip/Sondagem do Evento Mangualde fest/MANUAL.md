<!DOCTYPE html>
<html lang="pt-PT">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Sondagem do Evento</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Space+Mono:wght@400;700&family=Work+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  :root{
    --ink: #123832;
    --ink-deep: #0c2723;
    --cream: #F7F1E1;
    --marigold: #EFA23B;
    --marigold-deep: #C97F1F;
    --cherry: #C8433D;
    --line: rgba(247,241,225,0.22);
  }
  *{box-sizing:border-box; -webkit-tap-highlight-color: transparent;}
  html,body{height:100%;}
  html, body { overflow: hidden; }
  body{
    margin:0;
    min-height:100vh;
    background:
      radial-gradient(circle at 15% 10%, rgba(239,162,59,0.10), transparent 45%),
      radial-gradient(circle at 85% 90%, rgba(200,67,61,0.12), transparent 45%),
      var(--ink);
    color:var(--cream);
    font-family:'Work Sans', sans-serif;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:12px 24px 12px;
  }
  .stage{ width:100%; max-width:640px; }
  .eyebrow{
    font-family:'Space Mono', monospace;
    font-size:12px;
    letter-spacing:0.18em;
    text-transform:uppercase;
    color:var(--marigold);
    opacity:0.9;
    margin:0 0 6px 2px;
  }
  h1.display{
    font-family:'Anton', sans-serif;
    font-weight:400;
    text-transform:uppercase;
    letter-spacing:0.01em;
    line-height:0.95;
    margin:0 0 18px 2px;
    color:var(--cream);
  }
  .logo-wrap{
    display:flex;
    justify-content:center;
    margin:0 0 48px;
  }
  .logo-badge{
    width:72px;
    height:72px;
    border-radius:50%;
    overflow:hidden;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:8px;
    background:linear-gradient(135deg, rgba(255,255,255,0.98), rgba(247,241,225,0.9));
    box-shadow:0 12px 24px -10px rgba(0,0,0,0.35);
    border:3px solid rgba(255,255,255,0.75);
  }
  .event-logo{
    width:100%;
    height:100%;
    display:block;
    object-fit:contain;
    border-radius:50%;
  }
  /* ---- Ticket card, the signature element ---- */
  .ticket{
    position:relative;
    background:linear-gradient(180deg, #FBF6EA, var(--cream));
    color:var(--ink-deep);
    border-radius:18px;
    padding:20px 18px 18px;
    width:520px;
    max-width:92%;
    margin:0 auto;
    height:480px;
    display:flex;
    align-items:center;
    box-shadow: 0 12px 30px -12px rgba(0,0,0,0.35), 0 1px 0 rgba(255,255,255,0.4) inset;
  }
  .ticket::before, .ticket::after{
    content:"";
    position:absolute;
    width:18px; height:18px;
    background:var(--ink);
    border-radius:50%;
    top:50%; transform:translateY(-50%);
  }
  .ticket.minimal::before, .ticket.minimal::after{ display:none; }
  .ticket.minimal .perf{ display:none; }
  .ticket.minimal .stub-label{ display:none; }
  .ticket.minimal .ticket-body{ padding-left:18px; }
  .ticket::before{ left:-13px; }
  .ticket::after{ right:-13px; }
  .ticket .perf{
    position:absolute; top:0; bottom:0; width:0;
    border-left:2px dashed rgba(18,56,50,0.18);
  }
  .ticket .perf.left{ left:34px; }
  .stub-label{
    position:absolute;
    left:8px; top:70%;
    transform:translateY(-50%) rotate(-90deg);
    transform-origin:left top;
    font-family:'Space Mono', monospace;
    font-size:11px;
    font-weight:700;
    letter-spacing:0.24em;
    color:var(--ink-deep);
    background:rgba(255,255,255,0.95);
    padding:7px 10px;
    border-radius:999px;
    border:1px solid rgba(18,56,50,0.12);
    box-shadow:0 6px 16px -8px rgba(0,0,0,0.28);
    text-transform:uppercase;
    white-space:nowrap;
    z-index:2;
  }
  .ticket-body{ padding-left:34px; display:flex; flex-direction:column; justify-content:space-between; height:100%; }
  .ticket-body .long-text{ padding-left:12px; }
  .ticket-body .content{ flex:1 1 auto; }
  .ticket-body .footer-area{ margin-top:12px; }

  /* Larger layout tweaks for wide screens so the ticket matches the provided screenshot */
  @media (min-width:1100px){
    .stage{ max-width:640px; }
    .logo-badge{ width:96px; height:96px; padding:10px; }
    .ticket{ padding:28px 32px 28px; border-radius:18px; width:520px; max-width:92%; }
    .q-text{ font-size:22px; }
    .opt-btn{ padding:14px 16px; font-size:16px; }
    .stars .star{ font-size:36px; }
    .eyebrow{ font-size:13px; letter-spacing:0.20em; }
    .ticket-body{ padding-left:36px; }
  }

  /* progress stamps */
  .stamps{ display:flex; gap:8px; margin-bottom:20px; }
  .stamp-dot{
    width:11px; height:11px; border-radius:50%;
    border:2px solid var(--ink-deep);
    opacity:0.25;
  }
  .stamp-dot.done{ background:var(--cherry); border-color:var(--cherry); opacity:1; }
  .stamp-dot.current{ background:var(--marigold); border-color:var(--marigold-deep); opacity:1; }

  .q-text{
    font-family:'Anton', sans-serif;
    font-weight:400;
    font-size:20px;
    line-height:1.15;
    text-transform:uppercase;
    margin:0 0 20px;
  }
  label.field-label{
    display:block; font-size:12px; font-weight:600; letter-spacing:0.06em;
    text-transform:uppercase; color:rgba(18,56,50,0.6); margin:16px 0 6px;
  }
  input[type=text], input[type=email], input[type=tel]{
    width:100%; padding:14px 14px; border-radius:10px; border:2px solid rgba(18,56,50,0.15);
    font-family:'Work Sans', sans-serif; font-size:14px; background:#fff; color:var(--ink-deep);
  }
  input:focus{ outline:3px solid var(--marigold); outline-offset:1px; border-color:var(--marigold-deep); }

  .opt-btn{
    display:block; width:100%; text-align:left;
    padding:12px 12px; margin-bottom:8px;
    border-radius:12px; border:2px solid rgba(18,56,50,0.15);
    background:#fff; color:var(--ink-deep);
    font-family:'Work Sans', sans-serif; font-size:16px; font-weight:600;
    cursor:pointer; transition:transform .12s ease, border-color .12s ease, background .12s ease;
  }
  .opt-btn:active{ transform:scale(0.98); }
  .opt-btn.selected{ border-color:var(--cherry); background:#FCEBEA; }

  .stars{ display:flex; gap:8px; margin:6px 0 4px; }
  .star{
    font-size:32px; line-height:1; cursor:pointer; color:rgba(18,56,50,0.2);
    background:none; border:none; padding:0;
  }
  .star.filled{ color:var(--marigold-deep); }

  .cta{
    width:100%; padding:12px; margin-top:8px;
    border:none; border-radius:12px;
    background:var(--cherry); color:var(--cream);
    font-family:'Work Sans', sans-serif; font-weight:700; font-size:15px;
    letter-spacing:0.02em; cursor:pointer;
    box-shadow:0 8px 20px -8px rgba(200,67,61,0.6);
  }
  .cta:disabled{ opacity:0.35; cursor:not-allowed; box-shadow:none; }
  .cta:active:not(:disabled){ transform:scale(0.99); }
  .cta.secondary{
    background:transparent; color:var(--ink-deep); border:2px solid rgba(18,56,50,0.2);
    box-shadow:none;
  }
  .checkline{ display:flex; gap:10px; align-items:flex-start; margin-top:18px; font-size:13px; color:rgba(18,56,50,0.75); }
  .checkline input{ margin-top:3px; width:18px; height:18px; flex:none; }

  .gift-list{ margin:0 0 16px 18px; padding:0; color:rgba(18,56,50,0.75); }
  .gift-list li{ margin-bottom:6px; list-style:disc; }

  .hint{ font-size:12px; color:rgba(18,56,50,0.5); margin-top:4px; }

  /* hidden admin login modal */
  .admin-modal-backdrop{ position:fixed; inset:0; background:rgba(0,0,0,0.45); display:flex; align-items:center; justify-content:center; z-index:10000; }
  .admin-modal{ background:var(--cream); color:var(--ink-deep); padding:18px; border-radius:10px; width:320px; box-shadow:0 12px 40px rgba(0,0,0,0.5); }
  .admin-modal h3{ margin:0 0 10px; font-family:'Anton', sans-serif; font-size:18px; }
  .admin-modal input{ width:100%; padding:10px; margin:6px 0 10px; border-radius:8px; border:1px solid rgba(18,56,50,0.12); }
  .admin-modal .actions{ display:flex; gap:8px; justify-content:flex-end; }

  /* welcome */
  .welcome-cta{
    margin-top:22px; width:100%; padding:20px; border:none; border-radius:14px;
    background:var(--marigold); color:var(--ink-deep);
    font-family:'Anton', sans-serif; font-size:22px; text-transform:uppercase; letter-spacing:0.02em;
    cursor:pointer; box-shadow:0 14px 30px -12px rgba(239,162,59,0.55);
  }
  .welcome-cta:active{ transform:scale(0.99); }
  .top-links{ position:fixed; top:16px; right:16px; display:flex; gap:10px; }
  .icon-btn{
    width:38px; height:38px; border-radius:50%; border:1px solid var(--line);
    background:rgba(247,241,225,0.06); color:var(--cream);
    display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:16px;
  }
  .bottom-link{
    display:block; text-align:center; margin-top:18px; font-family:'Space Mono', monospace;
    font-size:12px; color:rgba(247,241,225,0.55); text-decoration:none; letter-spacing:0.04em;
    cursor: pointer;
  }
  .site-footer{
    position:fixed;
    left:0;
    right:0;
    bottom:0;
    padding:12px 24px;
    text-align:center;
    font-family:'Space Mono', monospace;
    font-size:12px;
    letter-spacing:0.08em;
    color:rgba(247,241,225,0.88);
    background:rgba(18,56,50,0.15);
    border-top:1px solid rgba(255,255,255,0.12);
    backdrop-filter: blur(10px);
  }

  .social-row{ margin-top:8px; display:inline-flex; gap:14px; align-items:center; justify-content:center; }
  .social-link{ display:inline-flex; align-items:center; justify-content:center; width:36px; height:36px; border-radius:50%; background:transparent; border:1px solid rgba(255,255,255,0.06); transition:transform .12s ease, background .12s ease; }
  .social-link svg{ width:20px; height:20px; fill:var(--cream); opacity:0.92; }
  .social-link:hover{ transform:translateY(-3px); background:rgba(255,255,255,0.03); }
  .social-link .custom-icon{ width:20px; height:20px; display:block; border-radius:50%;
    background: radial-gradient(circle at 50% 50%, #e9eefc 0%, #c8e7fb 35%, #ffd9e0 60%, #f7e9d6 78%);
    box-shadow: inset 0 0 0 3px rgba(255,255,255,0.06);
  }
  .contact-info{ color: var(--marigold); font-weight:600; }
  .side-back{
    position:fixed; left:12px; top:50%; transform:translateY(-50%);
    width:48px; height:48px; border-radius:12px; background:var(--marigold);
    color:var(--ink); border:none; display:flex; align-items:center; justify-content:center;
    font-size:18px; box-shadow:0 8px 20px -8px rgba(0,0,0,0.4); cursor:pointer; z-index:9999;
  }
  @media (max-width:520px){ .side-back{ left:8px; width:40px; height:40px; font-size:16px; } }

  /* hide internal back controls so only the yellow side button remains */
  #backLink, #qBack, #commentsBack, #giftBack, #backBtn { display: none !important; }

  /* gift screen */
  .gift-wrap{ text-align:center; }
  .stamp-mark{
    display:inline-block; font-family:'Anton', sans-serif; font-size:15px; letter-spacing:0.08em;
    color:var(--cherry); border:4px solid var(--cherry); border-radius:10px;
    padding:6px 14px; transform:rotate(-6deg); margin-bottom:18px;
    animation: stampin .35s ease-out;
  }
  .gift-item-name{
    margin-top:10px;
    font-family:'Anton', sans-serif;
    font-size:28px;
    text-transform:uppercase;
    color:var(--ink-deep);
    letter-spacing:0.04em;
  }
  @keyframes stampin{ from{ transform:rotate(-6deg) scale(1.6); opacity:0; } to{ transform:rotate(-6deg) scale(1); opacity:1; } }
  .code-box{
    font-family:'Space Mono', monospace; font-weight:700; font-size:30px; letter-spacing:0.12em;
    background:var(--ink); color:var(--marigold); border-radius:12px; padding:16px;
    margin:14px 0 18px; word-break:break-all;
  }
  .gift-desc{ font-size:14px; color:rgba(18,56,50,0.75); margin-bottom:6px; }

  /* admin / responses */
  .panel-title{ font-family:'Anton', sans-serif; font-size:22px; text-transform:uppercase; margin:0 0 16px; }
  textarea{
    width:100%; min-height:64px; padding:12px; border-radius:10px; border:2px solid rgba(18,56,50,0.15);
    font-family:'Work Sans', sans-serif; font-size:14px; color:var(--ink-deep); resize:vertical;
  }
  .qa-block{ border-top:1px dashed rgba(18,56,50,0.18); padding-top:14px; margin-top:14px; }
  table{ width:100%; border-collapse:collapse; font-size:13px; margin-top:10px; }
  th,td{ text-align:left; padding:8px 6px; border-bottom:1px solid rgba(18,56,50,0.12); }
  th{ font-family:'Space Mono', monospace; font-size:11px; text-transform:uppercase; color:rgba(18,56,50,0.55); }
  .scroll-table{ max-height:260px; overflow:auto; }
  .row-actions{ display:flex; gap:10px; margin-top:16px; }
  .empty-state{ font-size:14px; color:rgba(18,56,50,0.6); padding:20px 0; text-align:center; }
  .loading{ text-align:center; color:var(--cream); font-family:'Space Mono', monospace; font-size:13px; }

  /* ---- Admin dashboard: distinct full-screen scrollable layout ---- */
  .admin-overlay{
    position:fixed; inset:0; z-index:9500;
    background:
      radial-gradient(circle at 15% 10%, rgba(239,162,59,0.10), transparent 45%),
      radial-gradient(circle at 85% 90%, rgba(200,67,61,0.12), transparent 45%),
      var(--ink);
    overflow-y:auto;
    -webkit-overflow-scrolling:touch;
    padding:28px 18px 60px;
  }
  .admin-dash{
    width:100%; max-width:560px; margin:0 auto;
    background:linear-gradient(180deg, #FBF6EA, var(--cream));
    color:var(--ink-deep);
    border-radius:18px;
    padding:24px 22px 28px;
    box-shadow:0 16px 40px -14px rgba(0,0,0,0.5);
  }
  .admin-dash-header{
    display:flex; align-items:center; justify-content:space-between;
    margin-bottom:6px;
  }
  .admin-dash-title{
    font-family:'Anton', sans-serif; font-size:24px; text-transform:uppercase; letter-spacing:0.01em; margin:0;
  }
  .admin-close-btn{
    width:36px; height:36px; border-radius:50%; border:none; cursor:pointer;
    background:rgba(18,56,50,0.08); color:var(--ink-deep); font-size:16px;
    display:flex; align-items:center; justify-content:center; flex:none;
  }
  .admin-close-btn:active{ transform:scale(0.94); }
  .admin-sub{ font-family:'Space Mono', monospace; font-size:11px; letter-spacing:0.08em; text-transform:uppercase; color:rgba(18,56,50,0.5); margin:0 0 22px; }
  .admin-section{ margin-bottom:24px; }
  .admin-section-title{
    font-family:'Space Mono', monospace; font-size:11px; text-transform:uppercase; letter-spacing:0.08em;
    color:rgba(18,56,50,0.55); margin:0 0 10px;
  }
  .inv-grid{ border-radius:12px; border:1px solid rgba(18,56,50,0.10); overflow:hidden; background:#fff; }
  .inv-row{
    display:flex; align-items:center; justify-content:space-between;
    padding:11px 14px; border-bottom:1px solid rgba(18,56,50,0.08);
  }
  .inv-row:last-child{ border-bottom:none; }
  .inv-name{ font-weight:600; font-size:14px; }
  .inv-qty{
    font-family:'Space Mono', monospace; font-weight:700; font-size:13px;
    color:var(--marigold-deep); background:rgba(239,162,59,0.14);
    padding:3px 12px; border-radius:999px; min-width:28px; text-align:center;
  }
  .inv-qty.zero{ color:var(--cherry); background:rgba(200,67,61,0.12); }
  .admin-search-wrap{ position:relative; margin-bottom:10px; }
  .admin-search-wrap input[type=search]{
    width:100%; padding:12px 14px; border-radius:10px; border:2px solid rgba(18,56,50,0.15);
    font-family:'Work Sans', sans-serif; font-size:14px; background:#fff; color:var(--ink-deep);
  }
  .admin-table-wrap{
    border:1px solid rgba(18,56,50,0.10); border-radius:12px; background:#fff; overflow:hidden;
  }
  .admin-table-wrap table{ margin-top:0; }
  .admin-table-wrap thead th{ background:rgba(18,56,50,0.03); position:sticky; top:0; }
  .admin-row td{ cursor:pointer; }
  .admin-row:hover td, .admin-row:active td{ background:rgba(239,162,59,0.10); }
  .admin-count-badge{
    font-family:'Space Mono', monospace; font-size:11px; color:rgba(18,56,50,0.5); margin:8px 0 0;
  }


.contact-type-btn {
  min-height: 42px;
}
#fCountryCode {
  width: 100%;
  min-height: 44px;
  padding: 10px 12px;
  border-radius: 10px;
}


.inv-input {
  width: 90px;
  min-height: 40px;
  padding: 8px 10px;
  box-sizing: border-box;
  border: 1px solid rgba(18,56,50,0.18);
  border-radius: 8px;
  background: white;
  color: var(--ink-deep);
  font-weight: 700;
}

/* ===== Correções de ecrã / evitar conteúdo cortado ===== */
html, body {
  width: 100%;
  min-height: 100%;
  overflow-x: hidden;
}
body {
  overflow-y: auto;
}
#app {
  width: 100%;
  min-height: 100dvh;
  box-sizing: border-box;
  padding-bottom: max(24px, env(safe-area-inset-bottom));
}
.ticket,
.ticket-body,
.content,
.gift-wrap,
.admin-overlay,
.admin-dash {
  box-sizing: border-box;
  max-width: 100%;
}
.ticket {
  height: auto !important;
  min-height: 0 !important;
}
.ticket-body {
  height: auto !important;
  min-height: 0 !important;
  overflow: visible !important;
}
.content {
  height: auto !important;
  min-height: 0 !important;
  overflow: visible !important;
}
.footer-area {
  min-height: 42px;
}
input, select, textarea, button {
  max-width: 100%;
  box-sizing: border-box;
}
.opt-btn {
  white-space: normal !important;
  overflow-wrap: anywhere;
  word-break: normal;
  height: auto !important;
  min-height: 46px;
}
.q-text {
  overflow-wrap: anywhere;
  word-break: normal;
}
.row-actions {
  flex-wrap: wrap;
}
.row-actions > * {
  min-width: 0;
}
.gift-wrap {
  width: 100%;
  padding-bottom: 24px;
}
.gift-item-name,
.gift-desc {
  overflow-wrap: anywhere;
}
.code-box {
  max-width: 100%;
  overflow-wrap: anywhere;
}
@media (max-height: 760px) {
  #app {
    padding-top: 12px;
  }
  .logo-wrap {
    margin-top: 6px !important;
    margin-bottom: 12px !important;
  }
  .logo-badge {
    transform: scale(.82);
    transform-origin: center;
  }
  .display {
    margin-top: 6px !important;
    margin-bottom: 10px !important;
  }
  .ticket-body {
    padding-top: 16px !important;
    padding-bottom: 12px !important;
  }
  .content {
    padding-top: 8px !important;
    padding-bottom: 8px !important;
  }
}
@media (max-width: 520px) {
  #app {
    padding-left: 10px;
    padding-right: 10px;
  }
  .ticket {
    width: 100% !important;
  }
  .content {
    width: 100% !important;
  }
  .row-actions {
    gap: 8px !important;
  }
  .row-actions > button {
    flex: 1 1 140px !important;
  }
  .field-label {
    margin-top: 10px !important;
  }
}

</style>
</head>
<body>
<div class="stage" id="app">
  <div class="loading">a preparar…</div>
</div>
<div class="site-footer">
  <div class="contact-info">Contactos: geral@pjaferreira.com · Tel. 232 643 286</div>
  <div class="social-row" aria-hidden="false">
    <a class="social-link" href="https://www.pjaferreiraimob.com/" target="_blank" rel="noreferrer" aria-label="Site">
      <span class="custom-icon" aria-hidden="true"></span>
    </a>
    <a class="social-link" href="https://www.facebook.com/pjaimobiliaria" target="_blank" rel="noreferrer" aria-label="Facebook">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 12a10 10 0 10-11.58 9.9v-7h-2.4v-2.9h2.4V9.1c0-2.4 1.43-3.7 3.62-3.7 1.05 0 2.15.18 2.15.18v2.37h-1.21c-1.2 0-1.57.74-1.57 1.5v1.8h2.67l-.43 2.9h-2.24v7A10 10 0 0022 12z"/></svg>
    </a>
    <a class="social-link" href="https://www.instagram.com/pja.imobiliaria/" target="_blank" rel="noreferrer" aria-label="Instagram">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M7 2h10a5 5 0 015 5v10a5 5 0 01-5 5H7a5 5 0 01-5-5V7a5 5 0 015-5zm5 6.2A4.8 4.8 0 1016.8 13 4.8 4.8 0 0012 8.2zm6.2-3.4a1.12 1.12 0 11-1.12-1.12A1.12 1.12 0 0118.2 4.8zM12 10.8A1.2 1.2 0 1112 8.4a1.2 1.2 0 010 2.4z"/></svg>
    </a>
    <a class="social-link" href="https://www.youtube.com/@PJAImobiliaria" target="_blank" rel="noreferrer" aria-label="YouTube">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M10 15l5.19-3L10 9v6zm12-3c0 1.4-.12 2.6-.36 3.6-.25 1.05-1 1.9-2.05 2.15C18.1 18 12 18 12 18s-6.1 0-7.59-.25c-1.05-.25-1.8-1.1-2.05-2.15C2.12 14.6 2 13.4 2 12s.12-2.6.36-3.6c.25-1.05 1-1.9 2.05-2.15C5.9 6 12 6 12 6s6.1 0 7.59.25c1.05.25 1.8 1.1 2.05 2.15.24 1 .36 2.2.36 3.6z"/></svg>
    </a>
    <a class="social-link" href="https://www.linkedin.com/in/pja-ferreira-a1827820a" target="_blank" rel="noreferrer" aria-label="LinkedIn">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M4.98 3.5a2.5 2.5 0 11.02 0zM3 6.75h3.96V21H3V6.75zM9.75 6.75H13v1.95h.06c.38-.72 1.3-1.48 2.68-1.48 2.87 0 3.4 1.89 3.4 4.35V21h-3.96v-6.06c0-1.45-.03-3.32-2.02-3.32-2.02 0-2.33 1.58-2.33 3.2V21H9.75V6.75z"/></svg>
    </a>
  </div>

</div>

<!-- Side back button for quick navigation to previous step -->
<button id="sideBack" class="side-back" title="Voltar">←</button>

<script>
(function(){
  const DEFAULT_CONFIG = {
    eventName: "Feira do Evento",
    giftLabel: "Brinde da PJA",
    giftDescription: "Mostra este código ao staff da banca para levantares o teu brinde.",
    giftInventory: {
      'Caneta': 0,
      'Lápis': 0,
      'Chapéu': 0,
      'Boné': 0,
      'Óculos de sol': 0,
      'Porta-chaves': 0
    },
    questions: [
      {
        id:'q1',
        text:'Neste momento, tem interesse em:',
        type:'choice',
        options:['Comprar imóvel','Vender imóvel','Construir / Remodelar','Só a apreciar a feira']
      },
      {
        id:'q2a',
        text:'Que tipo de imóvel tem mais interesse?',
        type:'choice',
        options:['Moradia habitável / nova','Moradia para recuperar','Apartamento','Terreno','Quinta ou herdade'],
        dependsOn:{ id:'q1', values:['Comprar imóvel','Vender imóvel'] }
      },
      {
        id:'q3a',
        text:'Em que prazo pretende concretizar?',
        type:'choice',
        options:['Já decidido, a procurar ativamente','Nos próximos 3-6 meses','Mais de 6 meses / ainda a avaliar','Apenas a pesquisar'],
        dependsOn:{ id:'q1', values:['Comprar imóvel','Vender imóvel'] }
      },
      {
        id:'q4a',
        text:'Já conhecia a PJA? Onde?',
        type:'choice',
        options:['Site','Escritório','Placa de venda de um imóvel','Redes sociais','Acabei de conhecer aqui'],
        dependsOn:{ id:'q1', values:['Comprar imóvel','Vender imóvel'] }
      },
      {
        id:'q2b',
        text:'Em que podemos ajudar?',
        type:'choice',
        options:['Escolher o terreno','Projeto de arquitetura','Engenharia','Construção','Ainda não sei, quero perceber os serviços'],
        dependsOn:{ id:'q1', values:['Construir / Remodelar'] }
      },
      {
        id:'q3b',
        text:'Em que fase está o projeto?',
        type:'choice',
        options:['Já tenho terreno, quero avançar','Ainda a decidir/pesquisar','Só a recolher informação'],
        dependsOn:{ id:'q1', values:['Construir / Remodelar'] }
      },
      {
        id:'q4b',
        text:'Já conhecia a PJA? Onde?',
        type:'choice',
        options:['Site','Escritório','Placa de venda de um imóvel','Redes sociais','Acabei de conhecer aqui'],
        dependsOn:{ id:'q1', values:['Construir / Remodelar'] }
      },
      {
        id:'q2c',
        text:'Sabe quais os serviços que a PJA tem?',
        type:'choice',
        options:['Arquitetura','Engenharia','Levantamentos topográficos','Construção','Energia solar','Imobiliária','Todos os anteriores'],
        dependsOn:{ id:'q1', values:['Só a apreciar a feira'] }
      },
      {
        id:'q3c',
        text:'No futuro, prevê vir a precisar de algum destes serviços?',
        type:'choice',
        options:['Comprar','Vender','Construir','Energias','Não prevejo, por agora'],
        dependsOn:{ id:'q1', values:['Só a apreciar a feira'] }
      },
      {
        id:'q4c',
        text:'Já conhecia a PJA? Onde?',
        type:'choice',
        options:['Site','Escritório','Placa de venda de um imóvel','Redes sociais','Acabei de conhecer aqui'],
        dependsOn:{ id:'q1', values:['Só a apreciar a feira'] }
      }
    ]
  };

  const GIFT_ITEMS = ['Caneta','Lápis','Chapéu','Boné','Óculos de sol','Porta-chaves'];

  let config = null;
  let entries = [];
  let comments = [];
  let current = null; // {name,email,phone,consent,answers:{} }
  let qIndex = 0;
  let hideBackForNext = false; // when true, next screens hide the back link (but keep space)
  let lastEntry = null;
  let currentScreen = 'welcome';

  const app = document.getElementById('app');

  function esc(s){
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function genCode(){
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let s = '';
    for(let i=0;i<6;i++) s += chars[Math.floor(Math.random()*chars.length)];
    return s;
  }

  function renderExpired(){
    currentScreen = 'expired';
    app.innerHTML = `
      <div class="gift-wrap">
        <div class="eyebrow">Participação encerrada</div>
        <div class="ticket minimal">
          <div class="ticket-body" style="padding-left:18px;">
            <div class="content" style="display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; gap:14px;">
              <div style="font-family:'Anton', sans-serif; font-size:30px; text-transform:uppercase; color:var(--ink-deep);">
                Expirado
              </div>
              <div style="font-size:15px; line-height:1.5; color:rgba(18,56,50,0.75);">
                Os brindes desta participação já esgotaram.
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    setSideBack(false);
  }

  /* Removed automatic scaling (fitToViewport) to keep text sizes fixed across screens. */

  // =============================================================
  // MODO SEM BASE DE DADOS
  // Tudo é guardado no navegador (localStorage). Assim o site pode
  // funcionar apenas com o index.html, sem MySQL, PHP ou API.
  // =============================================================
  const STORAGE = {
    config: 'pja_feira_config_v1',
    entries: 'pja_feira_entries_v1',
    comments: 'pja_feira_comments_v1'
  };

  // Credenciais do painel local. Nota: num site sem servidor estas
  // credenciais não podem ser consideradas secretas.
  const ADMIN_EMAIL = 'maraoliveira@pjaferreira.com';
  const ADMIN_PASSWORD = 'adminpass';

  function cloneDefaultConfig(){
    return structuredClone(DEFAULT_CONFIG);
  }

  function readStorage(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }catch(e){
      console.error('Erro ao ler armazenamento local', e);
      return fallback;
    }
  }

  function writeStorage(key, value){
    try{
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    }catch(e){
      console.error('Erro ao guardar no armazenamento local', e);
      return false;
    }
  }

  async function loadConfig(){
    const stored = readStorage(STORAGE.config, null);
    config = cloneDefaultConfig();
    if(stored && typeof stored === 'object'){
      config.eventName = stored.eventName || config.eventName;
      config.giftLabel = stored.giftLabel || config.giftLabel;
      config.giftDescription = stored.giftDescription || config.giftDescription;
      if(stored.giftInventory && typeof stored.giftInventory === 'object'){
        config.giftInventory = { ...config.giftInventory, ...stored.giftInventory };
      }
    }
    // O questionário é sempre o definido no código.
    config.questions = structuredClone(DEFAULT_CONFIG.questions);
  }

  async function saveConfig(){
    writeStorage(STORAGE.config, {
      eventName: config.eventName,
      giftLabel: config.giftLabel,
      giftDescription: config.giftDescription,
      giftInventory: config.giftInventory
    });
  }

  async function claimGift(){
    const available = GIFT_ITEMS.filter(it => Number(config.giftInventory?.[it] || 0) > 0);
    if(!available.length) return null;
    const chosen = available[Math.floor(Math.random() * available.length)];
    config.giftInventory[chosen] = Math.max(0, Number(config.giftInventory[chosen] || 0) - 1);
    await saveConfig();
    return chosen;
  }

  async function loadEntries(){
    entries = readStorage(STORAGE.entries, []);
    if(!Array.isArray(entries)) entries = [];
    entries.sort((a,b)=> (b.ts||0)-(a.ts||0));
  }

  async function saveEntry(entry){
    entries.unshift(entry);
    writeStorage(STORAGE.entries, entries);
  }

  async function loadComments(){
    comments = readStorage(STORAGE.comments, []);
    if(!Array.isArray(comments)) comments = [];
  }

  async function addComment(text){
    if(!text || !text.trim()) return;
    const author = current?.name || 'Visitante';
    const comment = { author, text: text.trim(), ts: Date.now() };
    comments.unshift(comment);
    writeStorage(STORAGE.comments, comments);
  }

  function resetCurrent(){
    current = { name:'', email:'', phone:'', contact:'', concelho:'', consent:false, answers:{} };
    qIndex = 0;
    hideBackForNext = false;
  }

  function setSideBack(visible){
    const b = document.getElementById('sideBack');
    if(!b) return;
    b.style.display = visible ? 'flex' : 'none';
  }

  // ---------- SCREENS ----------
  function renderWelcome(){
    currentScreen = 'welcome';
    app.innerHTML = `
      <div class="logo-wrap" style="margin-bottom:24px;">
        <div class="logo-badge">
          <img class="event-logo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAb8AAAG/CAMAAAD/zSlAAAAAY1BMVEUAAAD////29vYEBAQtLS37+/u4uLi0tLRlZWUJCQnHx8fb29tMTEyXl5fz8/MVFRXt7e1xcXGEhISmpqZcXFysrKzAwMDj4+MgICB8fHzV1dVVVVWLi4saGho5OTmenp5FRUVnXFaFAAAURklEQVR4nO2dh5arvA6FqUkIKaRQQgq8/1MeTEkdRMCyYc7sb911z/wzhBg2NpIsy4YBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADw5/DGbsA3XLeeFHZzIrtGQ5ttI98t2lgNP6tzObyw42y0GpJoKUs0O6z3q6Q8nQ71xLeEm6CNw/DzLjbmC+mWr82KcFyTAdcKgjjU9rjaxqy9LfPh5z28nSpY8LVZEY7FoV/DJjrftLw1lOiXx+/nCvWMJxLw6lcQhydHfbOV6Hf6vJiVpjfCYNj1KwbT9JCrbbSi8TP9PNmFsdVKUKBfQRDlapvNrl9hN99+OFnqTbwDqtGvIBJ2vLJr59ev5Zznv6qfaYWDPbFuFIyf2x/vxIy12fyo0880/UuiqtkK+t/6x7NtNBhjMqjUz3SX5/JLuIcgFfaL/YP1IrjoCkoMQ6l+1eWruH5+/Xabn0/nJ4aWmOBAVOtnznIVAvLrF7acbnOadAdUrp+ZqghCsev3GXtpmG3/tn7lE8x9C9j1+4y9NMSrKU8kadDPdNfMjea3X7wW60XA3XpWdOhnuhn3E8ytX0603lfmBTGgRT/TPRi8VhyvfrYxp1o/5VkkPfqZbsjbbOb+57U4DxURb9tZ0aQfdySfWb893fYJD6Da9BNGDFd2DLf9Yvt027PpuvDa9DM3nOkVvPq1xV4a4ul2QH36mUHO12xe/dpiLw3WfrIuvMMqEY3P58bz6VeMjHnH8FlYMBP14G0jyQ6trHddnC7rwywOvu3DEqlhbzDqZxiXzoZPNhGNpT84u0P6lYTunuPrBJzj55WIvTRkXA3nhhDQfuRUt3E/gbMLgy8EjFcsjwyn/Wkbx28a7kx6FoKBbd5lBZQ3lymYz9n/vmm3eZyuC8GCuLhb1J3MzTSbxqhf0uE8VKQMjZ4ydinLqXUWrSHgWVLAqF+39VIyXReQCyHgudMW4JmN4dPvG+tFcPjP3381t6jjPgQ3+S/htF+6Yi8NsXyzp494x3eZAyxOIJt+HnGmF9zJp9JzIMaYDgELX1h+JGLSzzbOnW/shuVEYzDMtCWiPzgwrClg639fWi8FwVG20b8C2zOcJXkj4lz+W7j0S+imvjDpPBg2RFRmRQeEpYNRfPbLN7GXBv825UQ0Vt4Xkr/CYMrx6GcbXdbyC6f/PAbzxM+LQRrko/lM/S/pI99/H4NpEE8pGc2OpINoHPrZbWuOfkSEBhlc19/CjroXm9sU9CsU/Np5qJAoTfLb2JJOxFrOEmCxX4on6NQzeSSY+GJATkgTZil7dpb+5/WyXsy/EoOpIG9OLLu0mqX/fR97aVhOvyATEzY5OJVLkmRg6X89rJcaEfv7Gy5E8X6jnHjZdHoO/ZwvZ45eTj71eiJs0Mb5UsoS4Im/LPrLJ2J/09LPW7UjOeV8pe6D5AtQXr+esZeGqWXyOvEm2HwificdcKcGUMkQjLR+hQpD5JtcDIaqHyl3j21ybkbSEmcYP/tbLyUKixINgVj/4MqGKX8qKNYgWddIVr+i+5HOQ/tTzZdDzoJK/RziFqUyARh5+8U2dmTspV2/icVgVOp3JSyEjZwnLD9+UvE9i4gdTSwGo1I/8gV4lTqztH5HYmyw9pS4qTOlaVyl+rUXVTFNuWFIWj/Kegmua8KqY12HKo1C/Wwyhi13cln9yNhLaKyo6ctJxWCU6rciBimZpWSy9kvHmqPcMKi0JungOydKx8+ceMrl5kKl9Ct6DxV7ES46qe+ULBil+t1I/WQGIcnxkwrtFfIULaO8C1+i4dwo1Y9KBJXzgyX7H2m95OKI9608XjhLtZ0VpfpRDmA4Zv+jYi+z0rOhCqKVBZkmYsL8Sv1k7Rcq9uJWK0zJxGzXmYp8avVLSP1kkNOPtF7q3DjKd53QYkC1+hEP8Vj6FTeezHtp7GLK9ymLYku1n43R7JcR33+U9bK5T3pSJSWl83fY+IP+A9Wq+/ysTS/MnU8lBKrWfydm4GVWY0nYL7ZNp4bv7l9Bpg9MZjGgUv2ORBhRbgQarl/HzNHToJARx00mBqM0/knZ6XJBRInxk9xx9PFhmy7tF8vNf7Ex2vyRXHKbRP+jrBf3eH8r2z/uB/jgPI1MXpX62VQQarT5W8ovSF+eKjJBVHoJBw8q9aPcv1gmf0Im/kJaL69vtSuZ4jSNGIzS/CXCfJGsxjFcP3JZzdugSFow0ygpqVK/M3H1kgsgButHxl6it0FhMf1ZJJX6UYV8JJNIhuln013Kes8JoOK3n0ePgkr9iOHTlfR/h/Y/stT1Z5l5Ko/po7eOgir9RBUY4tr9XKbRw+2XHSXI55hOBrFFDGZ0E0ZZ/6P3FJpJur8D9aNXTOefHyCPn0JBJnXjJ5U9L33pA/W7Ud3vY2mRiJVSH4gn4EKo009pDuxA/cisltObGnbnKpcJZPIq04+cpfFlF4EM0E+IQ6Xlbn7sTaQLuPyP+x+ZfyC5emyQ/dI1cxR6P0U0yTwmyUUAHKjSz6EMdXcnG/wdNn5SQ0Lb1ZIFJpl3NRyAEv1seu2tK1+AcND4SU1HirylHxHjSOubfPzFgGr0MxJydaR8HbFB/W9QOJP0+MePwSgaP+mytvJ1/IboR1pULTtUddVjHz0Gw66fLSYW6NoADFNnQ/QjrZf2uhI70mjdjRyDUdL/OvZUkHabBtmfWzKW8u78PbjSFszIiwFV6HeOifX/Ze2lMerP51SbNnZ7m8gS9fHINV159Su3lEs6yvpdGIacvvp11doNCYfmRtYSHtmCYe5/dndZOF+6+K4xQD/DIPdGy6lLyokaY2eOq5GAffzs2sHK3XMkbvXXj4wHUdVouho7bhoao37lhey6aqKmDC/8IfYL+VjR2bgdO5COCqd+xUN86dzNi2cn4N76kbGXYEILanvCOn463RtwMqVN9taPnDmSnU0eEUb9bplQj1YwZnrd99WPjIJNZzVYf2j9bPFSq//3/m/zY/3iyy9fVAN3OXwHQR/9RPP2VKv8X7wvR4d+XyDOct3N6S2raiKeXWR72i82uRB/CrNAw6H0+zLHL99H8XcbYYjSHDz06n8deS/u77VeSP3M2O+m1xYKRzZft+f4eaBeyyJ0PbofMBRKP24YVwz07H+kV/OLrRet+kWMofp+9ie9mdbvdR4MnfoxWnl94y9k7GX+ewdPQ6N+vEZ6L/3O1PBp8QSExkKXfgFvrnIv/cgMCLmdYEZHk37cGz99r59Nx15EJj/Gzy5iapAaEsb/Vj9x4j3l/E2mkMtAtOjXVXG4r3497BdbLMIkBIx63q+poUO/VLxiFsc2VgNy8HrodyRjL7/a+TN06OfOSgvB/GGXrBIrHTAn0cN+oawX93PJ7S9DuX7W+lrK036EP2BPPUK/92g0mX3063eUVq1f3NgH7Yf4A0ppfatfx5qj37+ju1r9rEgkBpX2ZftBQ/ZT+K6wr+jWZOxlarv59UepfunpMTC2HyWq5vRtdntOtPu0NLs47ZEMXfdL3uzMROt7FQwo1M9aP49O7ce1LB0hae9V7qsmZOwl6Nnzb5c9wSir4dXpF+WG4T18c2KeeIAN3z7taL2srriRsZdw28/1zC23HevyH+kXLN8fbWKit33tSCvtZ9u8fDG5dqF3FYUrVfrV9MdYS6ZEv3h+/giqEHZE/1q2RGW8TX4/yiYLqNdxhV6cyDUwY5SjUKBfeim7wJt+xJ089K5FmBP6PYtyJK+ub95SVyh8jDwoOf0+H8c4OztGZYq96kcYErPeQZBTe6tfygKSWbubAXlLpDkkAhG6X4F8/c/dxMtTuxJEBmb/ajBEbaBnl84jnYchqeDUjpSjrCWT1q8wvKzAT6NDdi6HQbvFDyKKEVt531YTpdWeJxTINUfmboC9aJPhAMmitEOg8j/n6y/Yn067RV73IPv+fx9QxVz7OoBb4mX6XFmNvNlWf4fb7jBozZV2F0Jp/flnqC1l+0aRKTPiaQOOMzm2DNuAMCH107+vlTb9KFM+6Hkual+Jp5gP6a2ZuTFo+R55Usld7QegTT+PMt36GDB0EeTN48CczA1fDpz5IzcV0G/BaNOPfHNkPcYdm1xh/+Q+0EVohm2AYxsJ6QJqt2D06UcVhelTEM02zkQU5HC3Ssji4495yX50VEDXnw6lTz/K6HB7xX6pV9DDKSCL/w+uYNlRBU97DEaffmRNtPTrtxG9r9SmsuCFYULGXqwBMfP66+l+LVeYvT8a9aMKKrs9XvyUIVTXdhLrgslIicz2YRcyoW1IVEACjfqRU+Hfx9DO1PhVL1GzO+q9SO3eStu1M70uhEb9GDLBCl2IMnSumMKx6+PohaUDUt4ekC6gpTclSqd+tEH/zbd1mX9NEV3bWJF1MOT2LqJdwLXWAVSnfpThUfSdr77utKGy4R/WHx17kcy6Jvu2fHHoPujUj9wRuFrk0vro1n8o529aBXzkvtDvKLmy1R2lDPXuCqFVP7IKyz0B4ceoZPXLE12e6/HokzaiKLoqBVnOQu+SGK36kZsKCDKnbTGS+O2NnP02n4ZFOu9Fcsmt3bGNktZqalr16xh4TJHx2+rIb09d6rv3YxcWudGRdBEv2jnRuTOnXv3I3S9LrPTUOFAv9RmT07IzU+DQzB/bZL2XpxjpUOg8Jo4C0d+iVz86/6fCisP3ILB3DIPOyoYiDcOu8qYS0tPkiDGT12FptGC06ufRm8o9fXUcXU67xWKx250uUdytnSC752/QwxtHCcsF+YTM9cVgdOpnd+yrI0e8uqff0C/KkyG/1GRLptYE+mIwmsfPjpwiCawmcckmU6WKm8swxdr1HA6bHB6CZv06lqNL8BQSo2MvHPWW6EksnTEY7fp1+xDDeAxZHlXvfzWkWsJP3Kjv0DcLr3v8LJ5c0vkdhjuJvYTHQPv7rys2OYxIf+bzNBhBvw77Ygi6sxamwxj6ddSE6A9dAcH22mJytrFNroOXDG17rt5Vgn79xDVfWFcdBh11mXfLNnvCmcXzocEu53C4jl/6boz+Zxsep4Cd9Q+yVutmboXZ0GB2Hoy/++1I46fBOYQG79FG++mH8ufbrlkeZdf/NOOev2wOf/zp5Uz3/3wsSG1+sz0ehdH0YjjZHz+oZiz9OiKI3+N/zrZ5xd27JsLPe3s/lb+/1nu8ijtf6He//3YiPlJHwIsjvMQrh4riM9emcvc2STzjRZ3yUKP4ZP27p/NrYTT9jJze4/g73OhzDEvCRZ6lcbrO61+s5o1zn2d+kGb5QuTJ2EZ+2ASzdWXc2Md5LP5Ud7RTuIrKFHsv3O39ZfX5ZL+M46iZofT2p7KDHw+rQ1wP0Lcs3fiH/Dg0u7s/4+lXGACdm5V1EWTiwX8brJwgStPDehbE56p37UzRR4uedfaDWRb6/tI0Sv2yTTwv9BN97hT4YTYLKkdE1BddRqXqWytIw6zM9k1mmyg7LDeHSsBrNC876Mn1l9mp7JR5upllB9+PTLV37vlix9PP8BZfbbrTTrr4aaByYjO6iR4V12vhF+UOK2LdUrwqPnCbuc399au5pOJPVvmRlV8n8s/MeXXq7ea+u1Vm7ooBNrlsqlzxa1Sl0ZzqrEXbSJaBeCXeQutv6Fd8eybRBd3Lz68ZJ67Dx4s6K39R75BzMat/nfRVv6L/hfWUz61ewTdr1uRvrWahYB7X2YnzuAyhPvRrZhv2derZdfk39BOveSccaMfEYZv17gTr2nKMq1SwWj8v8muTMvvof0FwCEvKZdXF+LmprZSt1WRbnMyoOiQ1c/Hfd/3uSx7msVeN5us/ol95scdwwCjqh+0hFyfYVyc30moArfVLlk1m3/qt/3mG689mUcFsvi9FmTXreLdWs7b0YkblIcUxZV+963cPH8yavWH3f0M/gbje1b7npO5yTwXMRP+rzvza/+yomSPMPsbP4M1ifNGvYm++fulDv8aDmTdTw5e/o1/lcCX5+uthNM5u5Rup1UVO4npHsUVd2bB5/61rBbz0Y/ycxdVofJvnRjN+ljz0W8X1T5eslOldP7tQuLpj3h+xP0seGYKXZRy8teZlrt61gnh5ur/1WmPHhf1ZvhvPwd2Oqe7wzY/FyOccfrA/qyrrt1QcYZf6Veffbu7ZnOtSnu1+Uy2VqvSzS/3EoZ6RpGVBUSfTZn+Khrc/6fp3BlqdDrOlH7zLaG0Cfzlbn74rt+rEhf+XrQ9BMy1R+w+l/3dYr9P0bh/G92pbuyBdr0PhMpZEVqOfWy9ss43r3A3X68iq6unf/b/95h4+L/y/4ojUn+nTLwnnLYRhrqkVTWOqu5Dkx8Vuv99fRHWnbC1K3u4Wx/z6fAyJE1xuWeovRfylPP6un1HHZRZN7Z71I9HoWPjd6aEpoHRqliN64e6eluiJ+IsYASpl9ydPnPR4qFwPYYzd1svYX6+Ow2oDDWLbjuY57W5tvptuK+0XxxEvSbt+D1b+e/lHp+g9XpMDs90+xm+7/FMj1T1LprkLpWmZlKetgtz2tqrN7m2fI+BJef5fvaXg2NT2Z0UhRbI387HaAvqTvOp3W1pu+8FgcmyfvcPCQluHYxQ2BgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANPiH4lFFo0cLxikAAAAAElFTkSuQmCC" alt="Logo da PJA">
        </div>
      </div>
      <div class="ticket minimal">
        <div class="ticket-body" style="padding-left:18px;">
          <div class="content" style="text-align:center;">
            <div style="font-family:'Anton', sans-serif; font-size:30px; text-transform:uppercase; letter-spacing:0.04em; margin:0 auto 18px; color:var(--ink-deep);">
              Participação
            </div>
            <p style="margin:0 auto 22px; max-width:440px; font-size:16px; line-height:1.5; color:rgba(18,56,50,0.78);">
              Olá! Tem 1 minuto? Responda a 4 perguntas rápidas sobre o que procura e no final leva um pequeno brinde da PJA.
            </p>
            <button class="welcome-cta" id="startBtn">Começar ✦</button>
          </div>
        </div>
      </div>
    `;
    setSideBack(false);
    document.getElementById('startBtn').onclick = () => { resetCurrent(); renderQuestion(); };
  }

  function renderContact(){
    currentScreen = 'contact';
    app.innerHTML = `
      <div class="logo-wrap">
        <div class="logo-badge">
          <img class="event-logo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAb8AAAG/CAMAAAD/zSlAAAAAY1BMVEUAAAD////29vYEBAQtLS37+/u4uLi0tLRlZWUJCQnHx8fb29tMTEyXl5fz8/MVFRXt7e1xcXGEhISmpqZcXFysrKzAwMDj4+MgICB8fHzV1dVVVVWLi4saGho5OTmenp5FRUVnXFaFAAAURklEQVR4nO2dh5arvA6FqUkIKaRQQgq8/1MeTEkdRMCyYc7sb911z/wzhBg2NpIsy4YBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADw5/DGbsA3XLeeFHZzIrtGQ5ttI98t2lgNP6tzObyw42y0GpJoKUs0O6z3q6Q8nQ71xLeEm6CNw/DzLjbmC+mWr82KcFyTAdcKgjjU9rjaxqy9LfPh5z28nSpY8LVZEY7FoV/DJjrftLw1lOiXx+/nCvWMJxLw6lcQhydHfbOV6Hf6vJiVpjfCYNj1KwbT9JCrbbSi8TP9PNmFsdVKUKBfQRDlapvNrl9hN99+OFnqTbwDqtGvIBJ2vLJr59ev5Zznv6qfaYWDPbFuFIyf2x/vxIy12fyo0880/UuiqtkK+t/6x7NtNBhjMqjUz3SX5/JLuIcgFfaL/YP1IrjoCkoMQ6l+1eWruH5+/Xabn0/nJ4aWmOBAVOtnznIVAvLrF7acbnOadAdUrp+ZqghCsev3GXtpmG3/tn7lE8x9C9j1+4y9NMSrKU8kadDPdNfMjea3X7wW60XA3XpWdOhnuhn3E8ytX0603lfmBTGgRT/TPRi8VhyvfrYxp1o/5VkkPfqZbsjbbOb+57U4DxURb9tZ0aQfdySfWb893fYJD6Da9BNGDFd2DLf9Yvt027PpuvDa9DM3nOkVvPq1xV4a4ul2QH36mUHO12xe/dpiLw3WfrIuvMMqEY3P58bz6VeMjHnH8FlYMBP14G0jyQ6trHddnC7rwywOvu3DEqlhbzDqZxiXzoZPNhGNpT84u0P6lYTunuPrBJzj55WIvTRkXA3nhhDQfuRUt3E/gbMLgy8EjFcsjwyn/Wkbx28a7kx6FoKBbd5lBZQ3lymYz9n/vmm3eZyuC8GCuLhb1J3MzTSbxqhf0uE8VKQMjZ4ydinLqXUWrSHgWVLAqF+39VIyXReQCyHgudMW4JmN4dPvG+tFcPjP3381t6jjPgQ3+S/htF+6Yi8NsXyzp494x3eZAyxOIJt+HnGmF9zJp9JzIMaYDgELX1h+JGLSzzbOnW/shuVEYzDMtCWiPzgwrClg639fWi8FwVG20b8C2zOcJXkj4lz+W7j0S+imvjDpPBg2RFRmRQeEpYNRfPbLN7GXBv825UQ0Vt4Xkr/CYMrx6GcbXdbyC6f/PAbzxM+LQRrko/lM/S/pI99/H4NpEE8pGc2OpINoHPrZbWuOfkSEBhlc19/CjroXm9sU9CsU/Np5qJAoTfLb2JJOxFrOEmCxX4on6NQzeSSY+GJATkgTZil7dpb+5/WyXsy/EoOpIG9OLLu0mqX/fR97aVhOvyATEzY5OJVLkmRg6X89rJcaEfv7Gy5E8X6jnHjZdHoO/ZwvZ45eTj71eiJs0Mb5UsoS4Im/LPrLJ2J/09LPW7UjOeV8pe6D5AtQXr+esZeGqWXyOvEm2HwificdcKcGUMkQjLR+hQpD5JtcDIaqHyl3j21ybkbSEmcYP/tbLyUKixINgVj/4MqGKX8qKNYgWddIVr+i+5HOQ/tTzZdDzoJK/RziFqUyARh5+8U2dmTspV2/icVgVOp3JSyEjZwnLD9+UvE9i4gdTSwGo1I/8gV4lTqztH5HYmyw9pS4qTOlaVyl+rUXVTFNuWFIWj/Kegmua8KqY12HKo1C/Wwyhi13cln9yNhLaKyo6ctJxWCU6rciBimZpWSy9kvHmqPcMKi0JungOydKx8+ceMrl5kKl9Ct6DxV7ES46qe+ULBil+t1I/WQGIcnxkwrtFfIULaO8C1+i4dwo1Y9KBJXzgyX7H2m95OKI9608XjhLtZ0VpfpRDmA4Zv+jYi+z0rOhCqKVBZkmYsL8Sv1k7Rcq9uJWK0zJxGzXmYp8avVLSP1kkNOPtF7q3DjKd53QYkC1+hEP8Vj6FTeezHtp7GLK9ymLYku1n43R7JcR33+U9bK5T3pSJSWl83fY+IP+A9Wq+/ysTS/MnU8lBKrWfydm4GVWY0nYL7ZNp4bv7l9Bpg9MZjGgUv2ORBhRbgQarl/HzNHToJARx00mBqM0/knZ6XJBRInxk9xx9PFhmy7tF8vNf7Ex2vyRXHKbRP+jrBf3eH8r2z/uB/jgPI1MXpX62VQQarT5W8ovSF+eKjJBVHoJBw8q9aPcv1gmf0Im/kJaL69vtSuZ4jSNGIzS/CXCfJGsxjFcP3JZzdugSFow0ygpqVK/M3H1kgsgButHxl6it0FhMf1ZJJX6UYV8JJNIhuln013Kes8JoOK3n0ePgkr9iOHTlfR/h/Y/stT1Z5l5Ko/po7eOgir9RBUY4tr9XKbRw+2XHSXI55hOBrFFDGZ0E0ZZ/6P3FJpJur8D9aNXTOefHyCPn0JBJnXjJ5U9L33pA/W7Ud3vY2mRiJVSH4gn4EKo009pDuxA/cisltObGnbnKpcJZPIq04+cpfFlF4EM0E+IQ6Xlbn7sTaQLuPyP+x+ZfyC5emyQ/dI1cxR6P0U0yTwmyUUAHKjSz6EMdXcnG/wdNn5SQ0Lb1ZIFJpl3NRyAEv1seu2tK1+AcND4SU1HirylHxHjSOubfPzFgGr0MxJydaR8HbFB/W9QOJP0+MePwSgaP+mytvJ1/IboR1pULTtUddVjHz0Gw66fLSYW6NoADFNnQ/QjrZf2uhI70mjdjRyDUdL/OvZUkHabBtmfWzKW8u78PbjSFszIiwFV6HeOifX/Ze2lMerP51SbNnZ7m8gS9fHINV159Su3lEs6yvpdGIacvvp11doNCYfmRtYSHtmCYe5/dndZOF+6+K4xQD/DIPdGy6lLyokaY2eOq5GAffzs2sHK3XMkbvXXj4wHUdVouho7bhoao37lhey6aqKmDC/8IfYL+VjR2bgdO5COCqd+xUN86dzNi2cn4N76kbGXYEILanvCOn463RtwMqVN9taPnDmSnU0eEUb9bplQj1YwZnrd99WPjIJNZzVYf2j9bPFSq//3/m/zY/3iyy9fVAN3OXwHQR/9RPP2VKv8X7wvR4d+XyDOct3N6S2raiKeXWR72i82uRB/CrNAw6H0+zLHL99H8XcbYYjSHDz06n8deS/u77VeSP3M2O+m1xYKRzZft+f4eaBeyyJ0PbofMBRKP24YVwz07H+kV/OLrRet+kWMofp+9ie9mdbvdR4MnfoxWnl94y9k7GX+ewdPQ6N+vEZ6L/3O1PBp8QSExkKXfgFvrnIv/cgMCLmdYEZHk37cGz99r59Nx15EJj/Gzy5iapAaEsb/Vj9x4j3l/E2mkMtAtOjXVXG4r3497BdbLMIkBIx63q+poUO/VLxiFsc2VgNy8HrodyRjL7/a+TN06OfOSgvB/GGXrBIrHTAn0cN+oawX93PJ7S9DuX7W+lrK036EP2BPPUK/92g0mX3063eUVq1f3NgH7Yf4A0ppfatfx5qj37+ju1r9rEgkBpX2ZftBQ/ZT+K6wr+jWZOxlarv59UepfunpMTC2HyWq5vRtdntOtPu0NLs47ZEMXfdL3uzMROt7FQwo1M9aP49O7ce1LB0hae9V7qsmZOwl6Nnzb5c9wSir4dXpF+WG4T18c2KeeIAN3z7taL2srriRsZdw28/1zC23HevyH+kXLN8fbWKit33tSCvtZ9u8fDG5dqF3FYUrVfrV9MdYS6ZEv3h+/giqEHZE/1q2RGW8TX4/yiYLqNdxhV6cyDUwY5SjUKBfeim7wJt+xJ089K5FmBP6PYtyJK+ub95SVyh8jDwoOf0+H8c4OztGZYq96kcYErPeQZBTe6tfygKSWbubAXlLpDkkAhG6X4F8/c/dxMtTuxJEBmb/ajBEbaBnl84jnYchqeDUjpSjrCWT1q8wvKzAT6NDdi6HQbvFDyKKEVt531YTpdWeJxTINUfmboC9aJPhAMmitEOg8j/n6y/Yn067RV73IPv+fx9QxVz7OoBb4mX6XFmNvNlWf4fb7jBozZV2F0Jp/flnqC1l+0aRKTPiaQOOMzm2DNuAMCH107+vlTb9KFM+6Hkual+Jp5gP6a2ZuTFo+R55Usld7QegTT+PMt36GDB0EeTN48CczA1fDpz5IzcV0G/BaNOPfHNkPcYdm1xh/+Q+0EVohm2AYxsJ6QJqt2D06UcVhelTEM02zkQU5HC3Ssji4495yX50VEDXnw6lTz/K6HB7xX6pV9DDKSCL/w+uYNlRBU97DEaffmRNtPTrtxG9r9SmsuCFYULGXqwBMfP66+l+LVeYvT8a9aMKKrs9XvyUIVTXdhLrgslIicz2YRcyoW1IVEACjfqRU+Hfx9DO1PhVL1GzO+q9SO3eStu1M70uhEb9GDLBCl2IMnSumMKx6+PohaUDUt4ekC6gpTclSqd+tEH/zbd1mX9NEV3bWJF1MOT2LqJdwLXWAVSnfpThUfSdr77utKGy4R/WHx17kcy6Jvu2fHHoPujUj9wRuFrk0vro1n8o529aBXzkvtDvKLmy1R2lDPXuCqFVP7IKyz0B4ceoZPXLE12e6/HokzaiKLoqBVnOQu+SGK36kZsKCDKnbTGS+O2NnP02n4ZFOu9Fcsmt3bGNktZqalr16xh4TJHx2+rIb09d6rv3YxcWudGRdBEv2jnRuTOnXv3I3S9LrPTUOFAv9RmT07IzU+DQzB/bZL2XpxjpUOg8Jo4C0d+iVz86/6fCisP3ILB3DIPOyoYiDcOu8qYS0tPkiDGT12FptGC06ufRm8o9fXUcXU67xWKx250uUdytnSC752/QwxtHCcsF+YTM9cVgdOpnd+yrI0e8uqff0C/KkyG/1GRLptYE+mIwmsfPjpwiCawmcckmU6WKm8swxdr1HA6bHB6CZv06lqNL8BQSo2MvHPWW6EksnTEY7fp1+xDDeAxZHlXvfzWkWsJP3Kjv0DcLr3v8LJ5c0vkdhjuJvYTHQPv7rys2OYxIf+bzNBhBvw77Ygi6sxamwxj6ddSE6A9dAcH22mJytrFNroOXDG17rt5Vgn79xDVfWFcdBh11mXfLNnvCmcXzocEu53C4jl/6boz+Zxsep4Cd9Q+yVutmboXZ0GB2Hoy/++1I46fBOYQG79FG++mH8ufbrlkeZdf/NOOev2wOf/zp5Uz3/3wsSG1+sz0ehdH0YjjZHz+oZiz9OiKI3+N/zrZ5xd27JsLPe3s/lb+/1nu8ijtf6He//3YiPlJHwIsjvMQrh4riM9emcvc2STzjRZ3yUKP4ZP27p/NrYTT9jJze4/g73OhzDEvCRZ6lcbrO61+s5o1zn2d+kGb5QuTJ2EZ+2ASzdWXc2Md5LP5Ud7RTuIrKFHsv3O39ZfX5ZL+M46iZofT2p7KDHw+rQ1wP0Lcs3fiH/Dg0u7s/4+lXGACdm5V1EWTiwX8brJwgStPDehbE56p37UzRR4uedfaDWRb6/tI0Sv2yTTwv9BN97hT4YTYLKkdE1BddRqXqWytIw6zM9k1mmyg7LDeHSsBrNC876Mn1l9mp7JR5upllB9+PTLV37vlix9PP8BZfbbrTTrr4aaByYjO6iR4V12vhF+UOK2LdUrwqPnCbuc399au5pOJPVvmRlV8n8s/MeXXq7ea+u1Vm7ooBNrlsqlzxa1Sl0ZzqrEXbSJaBeCXeQutv6Fd8eybRBd3Lz68ZJ67Dx4s6K39R75BzMat/nfRVv6L/hfWUz61ewTdr1uRvrWahYB7X2YnzuAyhPvRrZhv2derZdfk39BOveSccaMfEYZv17gTr2nKMq1SwWj8v8muTMvvof0FwCEvKZdXF+LmprZSt1WRbnMyoOiQ1c/Hfd/3uSx7msVeN5us/ol95scdwwCjqh+0hFyfYVyc30moArfVLlk1m3/qt/3mG689mUcFsvi9FmTXreLdWs7b0YkblIcUxZV+963cPH8yavWH3f0M/gbje1b7npO5yTwXMRP+rzvza/+yomSPMPsbP4M1ifNGvYm++fulDv8aDmTdTw5e/o1/lcCX5+uthNM5u5Rup1UVO4npHsUVd2bB5/61rBbz0Y/ycxdVofJvnRjN+ljz0W8X1T5eslOldP7tQuLpj3h+xP0seGYKXZRy8teZlrt61gnh5ur/1WmPHhf1ZvhvPwd2Oqe7wzY/FyOccfrA/qyrrt1QcYZf6Veffbu7ZnOtSnu1+Uy2VqvSzS/3EoZ6RpGVBUSfTZn+Khrc/6fp3BlqdDrOlH7zLaG0Cfzlbn74rt+rEhf+XrQ9BMy1R+w+l/3dYr9P0bh/G92pbuyBdr0PhMpZEVqOfWy9ss43r3A3X68iq6unf/b/95h4+L/y/4ojUn+nTLwnnLYRhrqkVTWOqu5Dkx8Vuv99fRHWnbC1K3u4Wx/z6fAyJE1xuWeovRfylPP6un1HHZRZN7Z71I9HoWPjd6aEpoHRqliN64e6eluiJ+IsYASpl9ydPnPR4qFwPYYzd1svYX6+Ow2oDDWLbjuY57W5tvptuK+0XxxEvSbt+D1b+e/lHp+g9XpMDs90+xm+7/FMj1T1LprkLpWmZlKetgtz2tqrN7m2fI+BJef5fvaXg2NT2Z0UhRbI387HaAvqTvOp3W1pu+8FgcmyfvcPCQluHYxQ2BgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANPiH4lFFo0cLxikAAAAAElFTkSuQmCC" alt="Logo da PJA">
        </div>
      </div>
      <div class="eyebrow">Ecrã final — Contacto</div>
      <h1 class="display" style="font-size:30px;">Recebe o teu brinde</h1>
      <div class="ticket">
        <div class="perf left"></div>
        <div class="stub-label">Contacto</div>
        <div class="ticket-body">
          <div class="content">
            <p style="margin:0 0 16px; font-size:14px; line-height:1.45; color:rgba(18,56,50,0.75);">
              Para lhe entregarmos o brinde e, se quiser, mantê-lo informado sobre imóveis e novidades da PJA:
            </p>

            <label class="field-label" for="fName">Nome</label>
            <input type="text" id="fName" placeholder="O seu nome" value="${esc(current.name)}">

            <label class="field-label">Como prefere ser contactado?</label>
            <div class="contact-type-row" style="display:flex; gap:8px; margin-bottom:10px;">
              <button type="button" class="cta secondary contact-type-btn" id="phoneTypeBtn" style="flex:1;">Telemóvel</button>
              <button type="button" class="cta secondary contact-type-btn" id="emailTypeBtn" style="flex:1;">Email</button>
            </div>

            <div id="phoneFields">
              <label class="field-label" for="fCountryCode">Indicativo internacional</label>
              <select id="fCountryCode">
                <option value="+351">🇵🇹 +351 Portugal</option>
                <option value="+34">🇪🇸 +34 Espanha</option>
                <option value="+33">🇫🇷 +33 França</option>
                <option value="+44">🇬🇧 +44 Reino Unido</option>
                <option value="+49">🇩🇪 +49 Alemanha</option>
                <option value="+39">🇮🇹 +39 Itália</option>
                <option value="+31">🇳🇱 +31 Países Baixos</option>
                <option value="+32">🇧🇪 +32 Bélgica</option>
                <option value="+41">🇨🇭 +41 Suíça</option>
                <option value="+43">🇦🇹 +43 Áustria</option>
                <option value="+353">🇮🇪 +353 Irlanda</option>
                <option value="+30">🇬🇷 +30 Grécia</option>
                <option value="+45">🇩🇰 +45 Dinamarca</option>
                <option value="+46">🇸🇪 +46 Suécia</option>
                <option value="+47">🇳🇴 +47 Noruega</option>
                <option value="+358">🇫🇮 +358 Finlândia</option>
                <option value="+1">🇺🇸 +1 EUA / Canadá</option>
                <option value="+55">🇧🇷 +55 Brasil</option>
                <option value="+244">🇦🇴 +244 Angola</option>
                <option value="+258">🇲🇿 +258 Moçambique</option>
                <option value="+27">🇿🇦 +27 África do Sul</option>
              </select>
              <label class="field-label" for="fPhone">Número de telemóvel</label>
              <input type="tel" id="fPhone" inputmode="tel" autocomplete="tel" placeholder="912 345 678">
            </div>

            <div id="emailFields" style="display:none;">
              <label class="field-label" for="fEmail">Email</label>
              <input type="email" id="fEmail" autocomplete="email" placeholder="nome@email.com">
            </div>

            <label class="field-label" for="fConcelho">Cidade / Zona <span style="font-weight:400;">(opcional)</span></label>
            <input type="text" id="fConcelho" placeholder="Cidade / Zona (opcional)" value="${esc(current.concelho)}">

            <label class="checkline">
              <input type="checkbox" id="fConsent" ${current.consent ? 'checked' : ''} required>
              <span>Autorizo a PJA a contactar-me sobre este assunto e a tratar os meus dados para esse fim.</span>
            </label>

            <button class="cta" id="contactNext" style="margin-top:18px;" disabled>Continuar →</button>
          </div>
          <div class="footer-area" style="display:flex; align-items:center; justify-content:center;">
            <a href="#" class="bottom-link" id="backLink" style="visibility:visible">← Voltar</a>
          </div>
        </div>
      </div>
    `;

    setSideBack(true);

    const name = document.getElementById('fName');
    const phone = document.getElementById('fPhone');
    const countryCode = document.getElementById('fCountryCode');
    const email = document.getElementById('fEmail');
    const concelho = document.getElementById('fConcelho');
    const consent = document.getElementById('fConsent');
    const next = document.getElementById('contactNext');
    const phoneFields = document.getElementById('phoneFields');
    const emailFields = document.getElementById('emailFields');
    const phoneTypeBtn = document.getElementById('phoneTypeBtn');
    const emailTypeBtn = document.getElementById('emailTypeBtn');

    let contactType = 'phone';

    function setContactType(type){
      contactType = type;
      const isPhone = type === 'phone';

      phoneFields.style.display = isPhone ? 'block' : 'none';
      emailFields.style.display = isPhone ? 'none' : 'block';

      phoneTypeBtn.classList.toggle('secondary', !isPhone);
      emailTypeBtn.classList.toggle('secondary', isPhone);

      validate();
    }

    function validate(){
      const phoneValue = phone.value.replace(/\D/g, '');
      const emailValue = email.value.trim();
      const okPhone = phoneValue.length >= 7;
      const okEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue);

      // O método escolhido é obrigatório; o outro é opcional.
      const selectedContactOk = contactType === 'phone' ? okPhone : okEmail;

      next.disabled = !(name.value.trim().length > 1 && selectedContactOk && consent.checked);
    }

    [name, phone, email, concelho].forEach(el => el.addEventListener('input', validate));
    phoneTypeBtn.onclick = () => setContactType('phone');
    emailTypeBtn.onclick = () => setContactType('email');
    setContactType('phone');
    countryCode.addEventListener('change', validate);
    consent.addEventListener('change', () => {
      current.consent = consent.checked;
    });

    next.onclick = () => {
      current.name = name.value.trim();
      current.concelho = concelho.value.trim();
      current.consent = consent.checked;

      const digits = phone.value.replace(/\D/g, '');
      current.phone = digits ? `${countryCode.value} ${digits}` : '';
      current.email = email.value.trim();

      // O método escolhido é o obrigatório. O outro, se preenchido, é opcional.
      current.contact = contactType === 'phone' ? current.phone : current.email;

      finishSurvey();
    };

    const backLink = document.getElementById('backLink');
    if(backLink) backLink.onclick = (e) => {
      e.preventDefault();
      renderQuestion();
    };
  }

  function getVisibleQuestions(){
    return config.questions.filter(q => {
      if(!q.dependsOn) return true;
      const ans = current.answers[q.dependsOn.id];
      return q.dependsOn.values.includes(ans);
    });
  }

  function renderQuestion(){
    currentScreen = 'question';
    const visible = getVisibleQuestions();
    const total = visible.length;

    if(!total){
      renderContact();
      return;
    }

    if(qIndex >= total) qIndex = total - 1;
    const q = visible[qIndex];

    const stampsHtml = visible.map((_,i) => {
      let cls = 'stamp-dot';
      if(i < qIndex) cls += ' done';
      else if(i === qIndex) cls += ' current';
      return `<div class="${cls}"></div>`;
    }).join('');

    const bodyHtml = `
      <div id="optRow">
        ${q.options.map(o => `<button type="button" class="opt-btn ${current.answers[q.id]===o?'selected':''}" data-val="${esc(o)}">${esc(o)}</button>`).join('')}
      </div>
    `;

    app.innerHTML = `
      <div class="logo-wrap">
        <div class="logo-badge">
          <img class="event-logo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAb8AAAG/CAMAAAD/zSlAAAAAY1BMVEUAAAD////29vYEBAQtLS37+/u4uLi0tLRlZWUJCQnHx8fb29tMTEyXl5fz8/MVFRXt7e1xcXGEhISmpqZcXFysrKzAwMDj4+MgICB8fHzV1dVVVVWLi4saGho5OTmenp5FRUVnXFaFAAAURklEQVR4nO2dh5arvA6FqUkIKaRQQgq8/1MeTEkdRMCyYc7sb911z/wzhBg2NpIsy4YBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADw5/DGbsA3XLeeFHZzIrtGQ5ttI98t2lgNP6tzObyw42y0GpJoKUs0O6z3q6Q8nQ71xLeEm6CNw/DzLjbmC+mWr82KcFyTAdcKgjjU9rjaxqy9LfPh5z28nSpY8LVZEY7FoV/DJjrftLw1lOiXx+/nCvWMJxLw6lcQhydHfbOV6Hf6vJiVpjfCYNj1KwbT9JCrbbSi8TP9PNmFsdVKUKBfQRDlapvNrl9hN99+OFnqTbwDqtGvIBJ2vLJr59ev5Zznv6qfaYWDPbFuFIyf2x/vxIy12fyo0880/UuiqtkK+t/6x7NtNBhjMqjUz3SX5/JLuIcgFfaL/YP1IrjoCkoMQ6l+1eWruH5+/Xabn0/nJ4aWmOBAVOtnznIVAvLrF7acbnOadAdUrp+ZqghCsev3GXtpmG3/tn7lE8x9C9j1+4y9NMSrKU8kadDPdNfMjea3X7wW60XA3XpWdOhnuhn3E8ytX0603lfmBTGgRT/TPRi8VhyvfrYxp1o/5VkkPfqZbsjbbOb+57U4DxURb9tZ0aQfdySfWb893fYJD6Da9BNGDFd2DLf9Yvt027PpuvDa9DM3nOkVvPq1xV4a4ul2QH36mUHO12xe/dpiLw3WfrIuvMMqEY3P58bz6VeMjHnH8FlYMBP14G0jyQ6trHddnC7rwywOvu3DEqlhbzDqZxiXzoZPNhGNpT84u0P6lYTunuPrBJzj55WIvTRkXA3nhhDQfuRUt3E/gbMLgy8EjFcsjwyn/Wkbx28a7kx6FoKBbd5lBZQ3lymYz9n/vmm3eZyuC8GCuLhb1J3MzTSbxqhf0uE8VKQMjZ4ydinLqXUWrSHgWVLAqF+39VIyXReQCyHgudMW4JmN4dPvG+tFcPjP3381t6jjPgQ3+S/htF+6Yi8NsXyzp494x3eZAyxOIJt+HnGmF9zJp9JzIMaYDgELX1h+JGLSzzbOnW/shuVEYzDMtCWiPzgwrClg639fWi8FwVG20b8C2zOcJXkj4lz+W7j0S+imvjDpPBg2RFRmRQeEpYNRfPbLN7GXBv825UQ0Vt4Xkr/CYMrx6GcbXdbyC6f/PAbzxM+LQRrko/lM/S/pI99/H4NpEE8pGc2OpINoHPrZbWuOfkSEBhlc19/CjroXm9sU9CsU/Np5qJAoTfLb2JJOxFrOEmCxX4on6NQzeSSY+GJATkgTZil7dpb+5/WyXsy/EoOpIG9OLLu0mqX/fR97aVhOvyATEzY5OJVLkmRg6X89rJcaEfv7Gy5E8X6jnHjZdHoO/ZwvZ45eTj71eiJs0Mb5UsoS4Im/LPrLJ2J/09LPW7UjOeV8pe6D5AtQXr+esZeGqWXyOvEm2HwificdcKcGUMkQjLR+hQpD5JtcDIaqHyl3j21ybkbSEmcYP/tbLyUKixINgVj/4MqGKX8qKNYgWddIVr+i+5HOQ/tTzZdDzoJK/RziFqUyARh5+8U2dmTspV2/icVgVOp3JSyEjZwnLD9+UvE9i4gdTSwGo1I/8gV4lTqztH5HYmyw9pS4qTOlaVyl+rUXVTFNuWFIWj/Kegmua8KqY12HKo1C/Wwyhi13cln9yNhLaKyo6ctJxWCU6rciBimZpWSy9kvHmqPcMKi0JungOydKx8+ceMrl5kKl9Ct6DxV7ES46qe+ULBil+t1I/WQGIcnxkwrtFfIULaO8C1+i4dwo1Y9KBJXzgyX7H2m95OKI9608XjhLtZ0VpfpRDmA4Zv+jYi+z0rOhCqKVBZkmYsL8Sv1k7Rcq9uJWK0zJxGzXmYp8avVLSP1kkNOPtF7q3DjKd53QYkC1+hEP8Vj6FTeezHtp7GLK9ymLYku1n43R7JcR33+U9bK5T3pSJSWl83fY+IP+A9Wq+/ysTS/MnU8lBKrWfydm4GVWY0nYL7ZNp4bv7l9Bpg9MZjGgUv2ORBhRbgQarl/HzNHToJARx00mBqM0/knZ6XJBRInxk9xx9PFhmy7tF8vNf7Ex2vyRXHKbRP+jrBf3eH8r2z/uB/jgPI1MXpX62VQQarT5W8ovSF+eKjJBVHoJBw8q9aPcv1gmf0Im/kJaL69vtSuZ4jSNGIzS/CXCfJGsxjFcP3JZzdugSFow0ygpqVK/M3H1kgsgButHxl6it0FhMf1ZJJX6UYV8JJNIhuln013Kes8JoOK3n0ePgkr9iOHTlfR/h/Y/stT1Z5l5Ko/po7eOgir9RBUY4tr9XKbRw+2XHSXI55hOBrFFDGZ0E0ZZ/6P3FJpJur8D9aNXTOefHyCPn0JBJnXjJ5U9L33pA/W7Ud3vY2mRiJVSH4gn4EKo009pDuxA/cisltObGnbnKpcJZPIq04+cpfFlF4EM0E+IQ6Xlbn7sTaQLuPyP+x+ZfyC5emyQ/dI1cxR6P0U0yTwmyUUAHKjSz6EMdXcnG/wdNn5SQ0Lb1ZIFJpl3NRyAEv1seu2tK1+AcND4SU1HirylHxHjSOubfPzFgGr0MxJydaR8HbFB/W9QOJP0+MePwSgaP+mytvJ1/IboR1pULTtUddVjHz0Gw66fLSYW6NoADFNnQ/QjrZf2uhI70mjdjRyDUdL/OvZUkHabBtmfWzKW8u78PbjSFszIiwFV6HeOifX/Ze2lMerP51SbNnZ7m8gS9fHINV159Su3lEs6yvpdGIacvvp11doNCYfmRtYSHtmCYe5/dndZOF+6+K4xQD/DIPdGy6lLyokaY2eOq5GAffzs2sHK3XMkbvXXj4wHUdVouho7bhoao37lhey6aqKmDC/8IfYL+VjR2bgdO5COCqd+xUN86dzNi2cn4N76kbGXYEILanvCOn463RtwMqVN9taPnDmSnU0eEUb9bplQj1YwZnrd99WPjIJNZzVYf2j9bPFSq//3/m/zY/3iyy9fVAN3OXwHQR/9RPP2VKv8X7wvR4d+XyDOct3N6S2raiKeXWR72i82uRB/CrNAw6H0+zLHL99H8XcbYYjSHDz06n8deS/u77VeSP3M2O+m1xYKRzZft+f4eaBeyyJ0PbofMBRKP24YVwz07H+kV/OLrRet+kWMofp+9ie9mdbvdR4MnfoxWnl94y9k7GX+ewdPQ6N+vEZ6L/3O1PBp8QSExkKXfgFvrnIv/cgMCLmdYEZHk37cGz99r59Nx15EJj/Gzy5iapAaEsb/Vj9x4j3l/E2mkMtAtOjXVXG4r3497BdbLMIkBIx63q+poUO/VLxiFsc2VgNy8HrodyRjL7/a+TN06OfOSgvB/GGXrBIrHTAn0cN+oawX93PJ7S9DuX7W+lrK036EP2BPPUK/92g0mX3063eUVq1f3NgH7Yf4A0ppfatfx5qj37+ju1r9rEgkBpX2ZftBQ/ZT+K6wr+jWZOxlarv59UepfunpMTC2HyWq5vRtdntOtPu0NLs47ZEMXfdL3uzMROt7FQwo1M9aP49O7ce1LB0hae9V7qsmZOwl6Nnzb5c9wSir4dXpF+WG4T18c2KeeIAN3z7taL2srriRsZdw28/1zC23HevyH+kXLN8fbWKit33tSCvtZ9u8fDG5dqF3FYUrVfrV9MdYS6ZEv3h+/giqEHZE/1q2RGW8TX4/yiYLqNdxhV6cyDUwY5SjUKBfeim7wJt+xJ089K5FmBP6PYtyJK+ub95SVyh8jDwoOf0+H8c4OztGZYq96kcYErPeQZBTe6tfygKSWbubAXlLpDkkAhG6X4F8/c/dxMtTuxJEBmb/ajBEbaBnl84jnYchqeDUjpSjrCWT1q8wvKzAT6NDdi6HQbvFDyKKEVt531YTpdWeJxTINUfmboC9aJPhAMmitEOg8j/n6y/Yn067RV73IPv+fx9QxVz7OoBb4mX6XFmNvNlWf4fb7jBozZV2F0Jp/flnqC1l+0aRKTPiaQOOMzm2DNuAMCH107+vlTb9KFM+6Hkual+Jp5gP6a2ZuTFo+R55Usld7QegTT+PMt36GDB0EeTN48CczA1fDpz5IzcV0G/BaNOPfHNkPcYdm1xh/+Q+0EVohm2AYxsJ6QJqt2D06UcVhelTEM02zkQU5HC3Ssji4495yX50VEDXnw6lTz/K6HB7xX6pV9DDKSCL/w+uYNlRBU97DEaffmRNtPTrtxG9r9SmsuCFYULGXqwBMfP66+l+LVeYvT8a9aMKKrs9XvyUIVTXdhLrgslIicz2YRcyoW1IVEACjfqRU+Hfx9DO1PhVL1GzO+q9SO3eStu1M70uhEb9GDLBCl2IMnSumMKx6+PohaUDUt4ekC6gpTclSqd+tEH/zbd1mX9NEV3bWJF1MOT2LqJdwLXWAVSnfpThUfSdr77utKGy4R/WHx17kcy6Jvu2fHHoPujUj9wRuFrk0vro1n8o529aBXzkvtDvKLmy1R2lDPXuCqFVP7IKyz0B4ceoZPXLE12e6/HokzaiKLoqBVnOQu+SGK36kZsKCDKnbTGS+O2NnP02n4ZFOu9Fcsmt3bGNktZqalr16xh4TJHx2+rIb09d6rv3YxcWudGRdBEv2jnRuTOnXv3I3S9LrPTUOFAv9RmT07IzU+DQzB/bZL2XpxjpUOg8Jo4C0d+iVz86/6fCisP3ILB3DIPOyoYiDcOu8qYS0tPkiDGT12FptGC06ufRm8o9fXUcXU67xWKx250uUdytnSC752/QwxtHCcsF+YTM9cVgdOpnd+yrI0e8uqff0C/KkyG/1GRLptYE+mIwmsfPjpwiCawmcckmU6WKm8swxdr1HA6bHB6CZv06lqNL8BQSo2MvHPWW6EksnTEY7fp1+xDDeAxZHlXvfzWkWsJP3Kjv0DcLr3v8LJ5c0vkdhjuJvYTHQPv7rys2OYxIf+bzNBhBvw77Ygi6sxamwxj6ddSE6A9dAcH22mJytrFNroOXDG17rt5Vgn79xDVfWFcdBh11mXfLNnvCmcXzocEu53C4jl/6boz+Zxsep4Cd9Q+yVutmboXZ0GB2Hoy/++1I46fBOYQG79FG++mH8ufbrlkeZdf/NOOev2wOf/zp5Uz3/3wsSG1+sz0ehdH0YjjZHz+oZiz9OiKI3+N/zrZ5xd27JsLPe3s/lb+/1nu8ijtf6He//3YiPlJHwIsjvMQrh4riM9emcvc2STzjRZ3yUKP4ZP27p/NrYTT9jJze4/g73OhzDEvCRZ6lcbrO61+s5o1zn2d+kGb5QuTJ2EZ+2ASzdWXc2Md5LP5Ud7RTuIrKFHsv3O39ZfX5ZL+M46iZofT2p7KDHw+rQ1wP0Lcs3fiH/Dg0u7s/4+lXGACdm5V1EWTiwX8brJwgStPDehbE56p37UzRR4uedfaDWRb6/tI0Sv2yTTwv9BN97hT4YTYLKkdE1BddRqXqWytIw6zM9k1mmyg7LDeHSsBrNC876Mn1l9mp7JR5upllB9+PTLV37vlix9PP8BZfbbrTTrr4aaByYjO6iR4V12vhF+UOK2LdUrwqPnCbuc399au5pOJPVvmRlV8n8s/MeXXq7ea+u1Vm7ooBNrlsqlzxa1Sl0ZzqrEXbSJaBeCXeQutv6Fd8eybRBd3Lz68ZJ67Dx4s6K39R75BzMat/nfRVv6L/hfWUz61ewTdr1uRvrWahYB7X2YnzuAyhPvRrZhv2derZdfk39BOveSccaMfEYZv17gTr2nKMq1SwWj8v8muTMvvof0FwCEvKZdXF+LmprZSt1WRbnMyoOiQ1c/Hfd/3uSx7msVeN5us/ol95scdwwCjqh+0hFyfYVyc30moArfVLlk1m3/qt/3mG689mUcFsvi9FmTXreLdWs7b0YkblIcUxZV+963cPH8yavWH3f0M/gbje1b7npO5yTwXMRP+rzvza/+yomSPMPsbP4M1ifNGvYm++fulDv8aDmTdTw5e/o1/lcCX5+uthNM5u5Rup1UVO4npHsUVd2bB5/61rBbz0Y/ycxdVofJvnRjN+ljz0W8X1T5eslOldP7tQuLpj3h+xP0seGYKXZRy8teZlrt61gnh5ur/1WmPHhf1ZvhvPwd2Oqe7wzY/FyOccfrA/qyrrt1QcYZf6Veffbu7ZnOtSnu1+Uy2VqvSzS/3EoZ6RpGVBUSfTZn+Khrc/6fp3BlqdDrOlH7zLaG0Cfzlbn74rt+rEhf+XrQ9BMy1R+w+l/3dYr9P0bh/G92pbuyBdr0PhMpZEVqOfWy9ss43r3A3X68iq6unf/b/95h4+L/y/4ojUn+nTLwnnLYRhrqkVTWOqu5Dkx8Vuv99fRHWnbC1K3u4Wx/z6fAyJE1xuWeovRfylPP6un1HHZRZN7Z71I9HoWPjd6aEpoHRqliN64e6eluiJ+IsYASpl9ydPnPR4qFwPYYzd1svYX6+Ow2oDDWLbjuY57W5tvptuK+0XxxEvSbt+D1b+e/lHp+g9XpMDs90+xm+7/FMj1T1LprkLpWmZlKetgtz2tqrN7m2fI+BJef5fvaXg2NT2Z0UhRbI387HaAvqTvOp3W1pu+8FgcmyfvcPCQluHYxQ2BgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANPiH4lFFo0cLxikAAAAAElFTkSuQmCC" alt="Logo da PJA">
        </div>
      </div>
      <div class="eyebrow">Participação — Pergunta ${qIndex+1} de ${total}</div>
      <div class="ticket">
        <div class="perf left"></div>
        <div class="stub-label">Participação</div>
        <div class="ticket-body">
          <div class="content">
            <div class="stamps">${stampsHtml}</div>
            <div class="q-text">${esc(q.text)}</div>
            ${bodyHtml}
            <div class="row-actions" style="margin-top:20px; display:flex; gap:12px;">
              <button class="cta secondary" id="qBack" style="flex:1;">← Voltar</button>
            </div>
          </div>
          <div class="footer-area" style="display:flex; align-items:center; justify-content:center;">
            <a href="#" class="bottom-link" id="backLink" style="visibility:visible">← Voltar</a>
          </div>
        </div>
      </div>
    `;

    document.querySelectorAll('#optRow .opt-btn').forEach(btn => {
      btn.onclick = () => {
        current.answers[q.id] = btn.dataset.val;
        advanceQuestion();
      };
    });

    const goBack = (e) => {
      e.preventDefault();
      if(qIndex === 0) renderWelcome();
      else {
        qIndex--;
        renderQuestion();
      }
    };

    const backBtn = document.getElementById('qBack');
    if(backBtn) backBtn.onclick = goBack;

    setSideBack(true);

    const backLink = document.getElementById('backLink');
    if(backLink) backLink.onclick = goBack;
  }

  function advanceQuestion(){
    const visible = getVisibleQuestions();
    if(qIndex < visible.length - 1){
      qIndex++;
      renderQuestion();
    } else {
      renderContact();
    }
  }

  async function finishSurvey(){
    app.innerHTML = `<div class="loading">a registar…</div>`;

    // Reserva o brinde diretamente na base de dados (operação atómica no servidor),
    // evitando que duas pessoas em simultâneo levem o mesmo último brinde.
    const chosen = await claimGift();

    const entry = {
      id: Date.now() + '-' + Math.random().toString(36).slice(2,7),
      ts: Date.now(),
      name: current.name,
      email: current.email,
      phone: current.phone,
      contact: current.contact,
      concelho: current.concelho,
      consent: current.consent,
      answers: current.answers,
      giftCode: genCode(),
      giftItem: chosen
    };

    await saveEntry(entry);
    lastEntry = entry;
    if(chosen){
      renderGift(entry);
    } else {
      renderNoGift(entry);
    }
  }

  function renderComments(entry){
    currentScreen = 'comments';
    const commentsHtml = comments.map(c => `
      <div class="comment-item">
        <div class="comment-meta"><strong>${esc(c.author)}</strong> · ${new Date(c.ts).toLocaleDateString('pt-PT')}</div>
        <div class="comment-text">${esc(c.text)}</div>
      </div>
    `).join('');

    app.innerHTML = `
      <div class="gift-wrap">
        <div class="eyebrow">Obrigado pela sua disponibilidade!</div>
        <div class="ticket">
          <div class="perf left"></div>
          <div class="stub-label">Comentários</div>
          <div class="ticket-body">
            <div class="content">
              <div class="panel-title" style="margin-bottom:12px;">Comentários dos visitantes</div>
              <div style="margin-bottom:16px; font-size:14px; color:rgba(18,56,50,0.75);">
                Ao responder ao questionário ganho um brinde. Os brindes são:
              </div>
              <ul class="gift-list">
                ${GIFT_ITEMS.map(item => `<li>${esc(item)}</li>`).join('')}
              </ul>
              <div class="comment-form" style="display:none;">
                <textarea id="commentText" placeholder="Escreve aqui o teu comentário..."></textarea>
                <button class="cta" id="submitComment" style="margin-top:10px;">Publicar comentário</button>
              </div>
              <div class="comment-list">
                ${commentsHtml || '<div class="comment-empty">Ainda não há comentários. Escreve o primeiro!</div>'}
              </div>
              <div class="row-actions" style="margin-top:16px; display:flex; gap:12px;">
                <button class="cta secondary" id="commentsBack" style="flex:1;">← Voltar</button>
                <button class="cta" id="showGiftBtn" style="flex:1;">Ver brinde</button>
              </div>
            </div>
            <div class="footer-area" style="display:flex; align-items:center; justify-content:center;">
              <a href="#" class="bottom-link" id="backLink" style="visibility:visible">← Voltar</a>
            </div>
          </div>
        </div>
      </div>
    `;

    setSideBack(true);

    document.getElementById('submitComment').onclick = async () => {
      const textarea = document.getElementById('commentText');
      const text = textarea.value.trim();
      if(!text) return;
      await addComment(text);
      textarea.value = '';
      renderComments(entry);
    };

    document.getElementById('showGiftBtn').onclick = () => { renderGift(entry); };
    const commentsBack = document.getElementById('commentsBack');
    if(commentsBack){
      commentsBack.onclick = (e) => { e.preventDefault(); renderQuestion(); };
    }

    const backLink = document.getElementById('backLink');
    if(backLink) backLink.onclick = (e) => { e.preventDefault(); renderQuestion(); };
  }

  function renderNoGift(entry){
    currentScreen = 'gift';
    app.innerHTML = `
      <div class="gift-wrap">
        <div class="eyebrow">Obrigado, ${esc(entry.name.split(' ')[0] || '')}!</div>
        <div class="ticket minimal">
          <div class="ticket-body" style="padding-left:18px;">
            <div class="content" style="display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; gap:14px;">
              <div style="font-family:'Anton', sans-serif; font-size:22px; text-transform:uppercase; color:var(--ink-deep);">Respostas registadas</div>
              <div style="font-size:15px; line-height:1.5; color:rgba(18,56,50,0.75);">Neste momento os brindes já esgotaram, mas obrigado pela sua participação!</div>
              <button class="cta" id="doneBtnNoGift" style="margin-top:12px;">Concluir</button>
            </div>
          </div>
        </div>
      </div>
    `;
    setSideBack(false);
    document.getElementById('doneBtnNoGift').onclick = () => { renderThankYou(entry); };
  }

  function renderGift(entry){
    currentScreen = 'gift';
    app.innerHTML = `
      <div class="gift-wrap">
        <div class="eyebrow">Obrigado, ${esc(entry.name.split(' ')[0] || '')}!</div>
        <div class="ticket">
          <div class="perf left"></div>
          <div class="stub-label">Brinde</div>
          <div class="ticket-body">
            <div class="content">
              <div class="stamp-mark" style="margin-bottom:20px;">GANHASTE ✦</div>
              <div style="font-family:'Anton', sans-serif; font-size:22px; text-transform:uppercase;">Aqui está o seu brinde da PJA</div>
              <div class="gift-item-name">${esc(entry.giftItem)}</div>
              <div class="gift-desc">${esc(config.giftDescription)}</div>
              <div class="code-box">${esc(entry.giftItem || 'Brinde surpresa')}</div>
              <button class="cta" id="doneBtn" style="margin-top:12px;">Concluir</button>
            </div>
            <div class="footer-area" style="display:flex; align-items:center; justify-content:center;">
              <a href="#" class="bottom-link" id="backLink" style="visibility:hidden">← Voltar</a>
            </div>
          </div>
        </div>
      </div>
    `;

    setSideBack(false);

    document.getElementById('doneBtn').onclick = () => { renderThankYou(entry); };
  }

  // ---------- ADMIN ----------
  function renderThankYou(entry){
    currentScreen = 'thankyou';
    app.innerHTML = `
      <div class="gift-wrap">
        <div class="eyebrow">Participação concluída</div>
        <div class="ticket minimal">
          <div class="ticket-body" style="padding-left:18px;">
            <div class="content" style="display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; gap:14px;">
              <div style="font-family:'Anton', sans-serif; font-size:28px; text-transform:uppercase; color:var(--ink-deep);">Obrigado pela sua disponibilidade!</div>
              <div style="font-size:15px; line-height:1.5; color:rgba(18,56,50,0.75);">O seu brinde foi atribuído. Mostre o código ao staff da banca para o levantar.</div>
            </div>
          </div>
        </div>
      </div>
    `;
    setSideBack(false);
  }

  async function renderAdmin(){
    await loadConfig();
    await loadEntries();
    await loadComments();
    currentScreen = 'admin';
    setSideBack(false);

    // ---- Inventory section: gift name + how many remain of each ----
    const invHtml = GIFT_ITEMS.map(it => {
      const qty = (config.giftInventory && config.giftInventory[it]!==undefined) ? Number(config.giftInventory[it]) : 0;
      return `
        <div class="inv-row">
          <div class="inv-name">${esc(it)}</div>
          <input class="inv-input" type="number" min="0" step="1" data-gift="${esc(it)}" value="${qty}">
        </div>
      `;
    }).join('');

    const rowsHtml = renderAdminRowsHtml(entries);

    app.innerHTML = `
      <div class="admin-overlay" id="adminOverlay">
        <div class="admin-dash">
          <div class="admin-dash-header">
            <h2 class="admin-dash-title">Painel de administração</h2>
            <button class="admin-close-btn" id="admClose" title="Fechar">✕</button>
          </div>
          <p class="admin-sub">Área reservada · ${esc((config && config.eventName) || 'Evento')}</p>

          <div class="admin-section">
            <div class="admin-section-title">Inventário de brindes</div>
            <div style="font-size:13px; color:rgba(18,56,50,0.7); margin-bottom:12px;">
              Defina a quantidade disponível de cada brinde. Quando chegar a 0, esse brinde deixa de aparecer.
            </div>
            <div class="inv-grid">${invHtml}</div>
            <button class="cta" id="saveInventory" style="margin-top:14px;">Guardar quantidades</button>
            <div id="inventorySaved" style="font-size:12px; margin-top:8px; color:rgba(18,56,50,0.65);"></div>
          </div>

          <div class="admin-section">
            <div class="admin-section-title">Participantes (${entries.length})</div>
            <div class="admin-search-wrap">
              <input type="search" id="adminSearch" placeholder="Procurar por nome ou número de telemóvel">
            </div>
            <div class="admin-table-wrap">
              <table>
                <thead><tr><th>Nome</th><th>Telemóvel / Email</th><th></th></tr></thead>
                <tbody id="adminRows">${rowsHtml}</tbody>
              </table>
            </div>
            <div class="admin-count-badge" id="adminCountBadge">A mostrar ${entries.length} de ${entries.length}</div>
          </div>
        </div>
      </div>
    `;

    document.getElementById('admClose').onclick = renderWelcome;

    document.getElementById('saveInventory').onclick = async () => {
      const nextInventory = {};
      document.querySelectorAll('.inv-input').forEach(input => {
        const value = Math.max(0, Math.floor(Number(input.value) || 0));
        nextInventory[input.dataset.gift] = value;
        input.value = value;
      });

      config.giftInventory = nextInventory;
      await saveConfig();

      const msg = document.getElementById('inventorySaved');
      msg.textContent = 'Quantidades guardadas.';
      setTimeout(() => { if(msg) msg.textContent = ''; }, 2500);
    };

    const adminSearch = document.getElementById('adminSearch');
    const adminRows = document.getElementById('adminRows');
    const adminCountBadge = document.getElementById('adminCountBadge');
    adminSearch.addEventListener('input', () => {
      const q = adminSearch.value.trim().toLowerCase();
      const filtered = entries.filter(e => (
        (e.name || '').toLowerCase().includes(q) ||
        (e.phone || '').toLowerCase().includes(q) ||
        (e.email || '').toLowerCase().includes(q)
      ));
      adminRows.innerHTML = renderAdminRowsHtml(filtered);
      adminCountBadge.textContent = `A mostrar ${filtered.length} de ${entries.length}`;
      addAdminRowHandlers();
    });

    function addAdminRowHandlers(){
      document.querySelectorAll('.admin-row').forEach(r => {
        r.onclick = () => { const id = r.dataset.id; const ent = entries.find(x=>x.id===id); if(ent) showEntryDetail(ent); };
      });
    }
    addAdminRowHandlers();
  }

  function renderAdminRowsHtml(list){
    if(!list.length){
      return `<tr><td colspan="3" class="empty-state">Sem resultados.</td></tr>`;
    }
    return list.map(e => `
      <tr class="admin-row" data-id="${e.id}">
        <td>${esc(e.name)}</td>
        <td>${esc(e.phone || '')}</td>
        <td style="text-align:right; color:rgba(18,56,50,0.4); white-space:nowrap;">Respostas →</td>
      </tr>
    `).join('');
  }

  function showEntryDetail(entry){
    // modal showing the questionnaire answers this person actually chose
    if(document.getElementById('adminDetail')) return;

    // only the questions that were actually shown to this person (respecting branching),
    // and that they actually answered
    const relevantQuestions = config.questions.filter(q => {
      if(q.dependsOn){
        const ans = entry.answers ? entry.answers[q.dependsOn.id] : undefined;
        if(!q.dependsOn.values.includes(ans)) return false;
      }
      return entry.answers && entry.answers[q.id] !== undefined && entry.answers[q.id] !== '';
    });

    const answersHtml = relevantQuestions.length ? relevantQuestions.map(q => {
      const val = entry.answers[q.id];
      const valueHtml = (q.type === 'rating')
        ? `<div style="font-size:18px; letter-spacing:2px;">${'★'.repeat(Number(val)||0)}${'☆'.repeat(5-(Number(val)||0))}</div>`
        : `<div>${esc(val)}</div>`;
      return `
        <div class="qa-block" style="margin-top:0; padding-top:0; border-top:none; border-bottom:1px dashed rgba(18,56,50,0.15); padding-bottom:12px; margin-bottom:12px;">
          <div style="font-family:'Space Mono', monospace; font-size:11px; text-transform:uppercase; letter-spacing:0.06em; color:rgba(18,56,50,0.5); margin-bottom:4px;">${esc(q.text)}</div>
          <div style="font-weight:700; color:var(--ink-deep);">${valueHtml}</div>
        </div>
      `;
    }).join('') : `<div class="empty-state">Esta pessoa ainda não respondeu ao questionário.</div>`;

    const div = document.createElement('div');
    div.id = 'adminDetail';
    div.className = 'admin-modal-backdrop';
    div.innerHTML = `
      <div class="admin-modal" style="width:360px; max-width:92vw;">
        <h3>${esc(entry.name)}</h3>
        <div style="font-size:13px; color:rgba(18,56,50,0.75); margin-bottom:14px;">
          ${esc([entry.phone, entry.email].filter(Boolean).join(' / '))} · ${new Date(entry.ts).toLocaleString('pt-PT')}
        </div>
        <div style="font-family:'Space Mono', monospace; font-size:11px; text-transform:uppercase; letter-spacing:0.08em; color:rgba(18,56,50,0.55); margin-bottom:8px;">Respostas ao questionário</div>
        <div style="max-height:320px; overflow:auto; margin-bottom:12px;">${answersHtml}</div>
        <div style="display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap;">
          <button class="cta secondary" id="detailDelete" style="background:#c43d3d; color:#fff;">Eliminar resposta</button>
          <button class="cta secondary" id="detailClose">Fechar</button>
        </div>
      </div>
    `;
    document.body.appendChild(div);
    const close = () => { const m = document.getElementById('adminDetail'); if(m) m.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = (e) => { if(e.key === 'Escape') close(); };
    document.getElementById('detailClose').onclick = close;
    document.getElementById('detailDelete').onclick = () => {
      const confirmed = window.confirm(`Tem a certeza que pretende eliminar a resposta de ${entry.name || 'esta pessoa'}?\n\nEsta ação remove permanentemente esta participação deste navegador.`);
      if(!confirmed) return;

      entries = entries.filter(e => e.id !== entry.id);
      writeStorage(STORAGE.entries, entries);
      close();
      renderAdmin();
    };
    div.addEventListener('click', (e) => { if(e.target === div) close(); });
    document.addEventListener('keydown', onKey);
  }

  // ---------- INIT ----------

  const sideBackBtn = document.getElementById('sideBack');
  if(sideBackBtn){
    sideBackBtn.onclick = (e) => {
      e.preventDefault();
      switch(currentScreen){
        case 'question':
          if(typeof qIndex !== 'undefined' && qIndex > 0){ qIndex--; renderQuestion(); }
          else { renderWelcome(); }
          break;
        case 'contact':
          renderQuestion();
          break;
        case 'gift':
          renderContact();
          break;
        case 'admin':
          renderWelcome();
          break;
        case 'expired':
          renderExpired();
          break;
        default:
          renderWelcome();
      }
    };
  }

  (async function init(){
    await loadConfig();
    await loadEntries();
    await loadComments();
    resetCurrent();
    renderWelcome();
  })();

  // hidden admin login: detect 5 clicks on logo to open
  let __logoClicks = 0;
  function showAdminLogin(){
    if(document.getElementById('adminModal')) return;
    const div = document.createElement('div');
    div.id = 'adminModal';
    div.className = 'admin-modal-backdrop';
    div.innerHTML = `
      <div class="admin-modal">
        <h3>Admin login</h3>
        <input id="adminEmailIn" placeholder="Email" type="email" />
        <input id="adminPassIn" placeholder="Password" type="password" />
        <div style="color:#c43; font-size:13px; display:none;" id="adminErr">Credenciais inválidas</div>
        <div class="actions">
          <button class="cta secondary" id="adminCancel">Cancelar</button>
          <button class="cta" id="adminLogin">Entrar</button>
        </div>
      </div>
    `;
    document.body.appendChild(div);
    document.getElementById('adminCancel').onclick = () => { hideAdminLogin(); };
    document.getElementById('adminLogin').onclick = async () => {
      const e = document.getElementById('adminEmailIn').value.trim();
      const p = document.getElementById('adminPassIn').value;
      const btn = document.getElementById('adminLogin');
      const err = document.getElementById('adminErr');
      err.style.display = 'none';
      btn.disabled = true;
      try{
        const ok = e === ADMIN_EMAIL && p === ADMIN_PASSWORD;
        if(ok){
          hideAdminLogin();
          renderAdmin();
        } else {
          err.style.display = 'block';
        }
      }catch(ex){
        console.error('Falha no login de admin:', ex);
        err.textContent = ex && ex.message
          ? ex.message
          : 'Não foi possível contactar o servidor.';
        err.style.display = 'block';
      }finally{
        btn.disabled = false;
      }
    };
  }
  function hideAdminLogin(){
    const m = document.getElementById('adminModal');
    if(m) m.remove();
  }
  document.addEventListener('click', (ev) => {
    const logo = ev.target.closest('.logo-badge');
    if(logo){
      __logoClicks++;
      if(__logoClicks >= 5){ __logoClicks = 0; showAdminLogin(); }
    }
  });
})();
</script>
</body>
</html>